﻿@echo off
chcp 65001 >nul
cd /d "%~dp0"
title huishan-498
echo 一键回删：阿里云200 → 前望后扫 → 剩498停
echo.
where node >nul 2>nul
if errorlevel 1 (
  echo 未找到 node，请先安装 Node.js
  pause
  exit /b 1
)
node "%~dp0本机回删.js" --out
echo.
pause
