#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
node "./抓四项转攻击语.js" --history 20 "$@"
status=$?
if [[ -f "./攻击语一行.txt" ]]; then
  echo
  echo "======= 可复制 ======="
  cat "./攻击语一行.txt"
  echo "======================"
fi
exit "$status"
