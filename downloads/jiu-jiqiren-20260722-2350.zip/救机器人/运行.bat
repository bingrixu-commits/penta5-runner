﻿@echo off
chcp 65001 >nul
cd /d "%~dp0"
title grab-attack
echo ========================================
echo   抓码 - 攻击语（本机）
echo ========================================
echo.
where node >nul 2>nul
if errorlevel 1 (
  echo [ERROR] 未找到 node。请安装 Node.js
  pause
  exit /b 1
)
node "%~dp0抓四项转攻击语.js" --history 20
if errorlevel 1 (
  echo [ERROR] 抓取失败
  pause
  exit /b 1
)
if exist "%~dp0攻击语一行.txt" (
  type "%~dp0攻击语一行.txt" | clip
  echo.
  echo 已复制攻击语到剪贴板
)
echo.
pause
