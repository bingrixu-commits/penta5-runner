#!/usr/bin/env node
/**
 * 本机工具：抓四项转攻击语（给转换器用，可复制）
 *
 * 流程：
 *   1) 先 http://8.210.5.221/ 取 ④二数合 → 定三位方向
 *   2) 再 http://8.210.5.221:3001/panel（登录后 /state）取：
 *      - 组内定位命中率最高 2 位（从 0123456789 删码，不写除十X）
 *      - 同组合尾命中率最高
 *      - 开奖下三对数「本期排除」
 *
 *   node 抓四项转攻击语.js
 */
"use strict";

const fs = require("fs");
const path = require("path");
const http = require("http");

const FULL_POOL = "0123456789";
const ENSEMBLE_URL = process.env.ENSEMBLE_URL || "http://8.210.5.221/";
const PANEL_PASSWORD = process.env.PANEL_PASSWORD || "147258";
const PANEL_BASES = (
  process.env.PANEL_BASES ||
  "http://8.210.5.221:3001,http://127.0.0.1:3001"
)
  .split(",")
  .map((s) => s.trim())
  .filter(Boolean);

/** 三位搭配 → 面板合尾键 */
const TRIO_HEWEI_KEYS = {
  百十个: ["qianBaiShi"],
  千百十: ["wanQianBai"],
  千百个: ["wanQianShi", "qianBaiGe"],
  千十个: ["wanBaiShi"]
};

const DEFAULT_ROOTS = [
  path.resolve(__dirname, "../../penta5-runner"),
  path.resolve(__dirname, "../penta5-runner"),
  "/root/penta5-runner",
  path.resolve(process.cwd(), "penta5-runner"),
  process.cwd()
];

/** 四位：wan=千 qian=百 bai=十 shi=个 */
const POS_META = {
  wan: { label: "千", nameRe: /千位/ },
  qian: { label: "百", nameRe: /百位/ },
  bai: { label: "十", nameRe: /十位/ },
  shi: { label: "个", nameRe: /个位/ }
};

const TRIO_DEFS = [
  { id: "百十个", keys: ["qian", "bai", "shi"], heweiTok: "百十个合", re: /百十个/ },
  { id: "千百十", keys: ["wan", "qian", "bai"], heweiTok: "千百十合", re: /千百十(?!个)/ },
  { id: "千百个", keys: ["wan", "qian", "shi"], heweiTok: "千百个合", re: /千百个/ },
  { id: "千十个", keys: ["wan", "bai", "shi"], heweiTok: "千十个合", re: /千十个/ }
];

function stripDigit(pool, digit) {
  const d = String(digit == null ? "" : digit).replace(/\D/g, "").slice(0, 1);
  if (!d) return pool;
  return String(pool).split(d).join("");
}

function num(v, fb) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fb;
}

function rateOf(row) {
  if (row == null) return -1;
  if (typeof row === "number") return Number.isFinite(row) ? row : -1;
  if (typeof row !== "object") return -1;
  const perf = row.performance && typeof row.performance === "object" ? row.performance : {};
  const r120 = num(row.rate120, -1);
  if (r120 >= 0) return r120;
  return num(row.rate30 != null ? row.rate30 : perf.rate, -1);
}

function fmtRate(v) {
  const n = rateOf(typeof v === "object" ? v : { rate120: v });
  if (n < 0) return "--";
  return n.toFixed(2) + "%";
}

function readJson(file) {
  return JSON.parse(fs.readFileSync(file, "utf8"));
}

function findRunnerRoot(cliRoot) {
  if (cliRoot && fs.existsSync(cliRoot)) return path.resolve(cliRoot);
  for (const root of DEFAULT_ROOTS) {
    const a = path.join(root, "data/algorithm-projects/three-duishu/state.json");
    if (fs.existsSync(a)) return root;
  }
  return null;
}

function httpGetText(url, timeoutMs) {
  return new Promise((resolve, reject) => {
    const req = http.get(url, { timeout: timeoutMs || 8000 }, (res) => {
      let buf = "";
      res.setEncoding("utf8");
      res.on("data", (c) => (buf += c));
      res.on("end", () => {
        if (res.statusCode && res.statusCode >= 400) {
          reject(new Error("HTTP " + res.statusCode + " " + url));
          return;
        }
        resolve(buf);
      });
    });
    req.on("error", reject);
    req.on("timeout", () => {
      req.destroy();
      reject(new Error("timeout " + url));
    });
  });
}

function cookieFromSetCookie(setCookie) {
  if (!setCookie) return "";
  const arr = Array.isArray(setCookie) ? setCookie : [setCookie];
  return arr
    .map((s) => String(s).split(";")[0])
    .filter(Boolean)
    .join("; ");
}

function httpJson(url, opts) {
  opts = opts || {};
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    const body = opts.body ? JSON.stringify(opts.body) : null;
    const req = http.request(
      {
        hostname: u.hostname,
        port: u.port || 80,
        path: u.pathname + u.search,
        method: opts.method || "GET",
        headers: Object.assign(
          { Accept: "application/json" },
          body
            ? {
                "Content-Type": "application/json",
                "Content-Length": Buffer.byteLength(body)
              }
            : {},
          opts.headers || {}
        ),
        timeout: opts.timeout || 30000
      },
      (res) => {
        let buf = "";
        res.setEncoding("utf8");
        res.on("data", (c) => (buf += c));
        res.on("end", () => {
          let data = null;
          try {
            data = JSON.parse(buf);
          } catch (_e) {
            data = { raw: buf.slice(0, 400) };
          }
          if (res.statusCode && res.statusCode >= 400) {
            reject(
              new Error(
                "HTTP " +
                  res.statusCode +
                  " " +
                  url +
                  " :: " +
                  ((data && (data.error || data.message)) || buf.slice(0, 120))
              )
            );
            return;
          }
          resolve({ status: res.statusCode, headers: res.headers, data });
        });
      }
    );
    req.on("error", reject);
    req.on("timeout", () => {
      req.destroy();
      reject(new Error("timeout " + url));
    });
    if (body) req.write(body);
    req.end();
  });
}

/** 登录面板后拉 /state（定位/合尾/对数） */
async function fetchPanelState() {
  const errors = [];
  for (const base of PANEL_BASES) {
    const root = String(base || "").replace(/\/$/, "");
    try {
      const login = await httpJson(root + "/login", {
        method: "POST",
        body: { password: PANEL_PASSWORD },
        timeout: 15000
      });
      const cookie = cookieFromSetCookie(login.headers && login.headers["set-cookie"]);
      const resp = await httpJson(root + "/state", {
        timeout: 60000,
        headers: cookie ? { Cookie: cookie } : {}
      });
      if (!resp.data || resp.data.ok === false) {
        throw new Error((resp.data && resp.data.error) || "state not ok");
      }
      return { base: root, state: resp.data, panelUrl: root + "/panel" };
    } catch (e) {
      errors.push(root + " → " + (e && e.message ? e.message : e));
    }
  }
  throw new Error("面板登录/拉 state 失败：\n" + errors.join("\n"));
}

function panelPosRate(row) {
  if (!row) return -1;
  const r120 = num(row.rate120, -1);
  if (r120 >= 0) return r120;
  const r30 = num(row.rate30, -1);
  if (r30 >= 0) return r30;
  const perf = row.performance && typeof row.performance === "object" ? row.performance : {};
  return num(perf.rate, -1);
}

function panelHeweiRate(row) {
  if (!row) return -1;
  const st = row.stability && typeof row.stability === "object" ? row.stability : {};
  const r120 = num(row.rate120 != null ? row.rate120 : st.lower120, -1);
  if (r120 >= 0) return r120;
  const perf = row.performance && typeof row.performance === "object" ? row.performance : {};
  return num(perf.rate, -1);
}

/**
 * 从面板 state 按三位方向取：组内定位、同组合尾、三对数本期排除
 */
function pickFromPanelState(state, trio) {
  const pred = (state && state.currentPrediction) || {};
  const posMap = Object.create(null);
  const scope = Object.create(null);
  (trio.keys || []).forEach((k) => {
    scope[k] = true;
  });

  // 优先 fourPosExclude（带 rate120）
  const four = pred.fourPosExclude || {};
  const items = Array.isArray(four.items) ? four.items : [];
  items.forEach((it) => {
    if (!it || !scope[it.key]) return;
    const digit = String(it.code == null ? "" : it.code).replace(/\D/g, "").slice(0, 1);
    if (!/^\d$/.test(digit)) return;
    upsertPos(
      posMap,
      it.key,
      digit,
      panelPosRate(it),
      (POS_META[it.key] ? POS_META[it.key].label : it.key) + "位杀" + digit,
      "panel-fourPos"
    );
  });

  // 补洞：positionKills
  const kills = pred.positionKills || {};
  Object.keys(kills).forEach((k) => {
    if (!scope[k] || posMap[k]) return;
    const row = kills[k];
    if (!row) return;
    const digit = String(
      row.selectedDigit || row.primaryDigit || row.recommendDigit || row.main || ""
    )
      .replace(/\D/g, "")
      .slice(0, 1);
    if (!/^\d$/.test(digit)) return;
    upsertPos(
      posMap,
      k,
      digit,
      panelPosRate(row),
      (POS_META[k] ? POS_META[k].label : k) + "位杀" + digit,
      "panel-positionKills"
    );
  });

  // 合尾：同组键，命中率最高
  const ind = pred.independentHeweiKills || {};
  const heweiKeys = TRIO_HEWEI_KEYS[trio.id] || [];
  const heweiCands = [];
  heweiKeys.forEach((hk) => {
    const row = ind[hk];
    if (!row) return;
    const digit = String(row.killDigit || row.primaryDigit || "").replace(/\D/g, "").slice(0, 1);
    if (!/^\d$/.test(digit)) return;
    heweiCands.push({
      digit,
      rate120: panelHeweiRate(row),
      name: row.label || trio.id + "合尾杀" + digit,
      source: "panel-hewei." + hk,
      trioId: trio.id
    });
  });
  // 若同组键缺失，在全部独立合尾里按 label 匹配 trio
  if (!heweiCands.length) {
    Object.keys(ind).forEach((hk) => {
      const row = ind[hk];
      if (!row) return;
      const label = String(row.label || "");
      if (trioFromText(label).id !== trio.id) return;
      const digit = String(row.killDigit || row.primaryDigit || "").replace(/\D/g, "").slice(0, 1);
      if (!/^\d$/.test(digit)) return;
      heweiCands.push({
        digit,
        rate120: panelHeweiRate(row),
        name: label || hk,
        source: "panel-hewei." + hk,
        trioId: trio.id
      });
    });
  }

  const dui =
    pred.threeDuishu ||
    state.threeDuishuRecommendation ||
    {};
  const pair = String(dui.selectedPair || dui.selectedPairCode || "")
    .replace(/\D/g, "")
    .slice(0, 2);

  return {
    posMap,
    heweiCands,
    pair: /^\d{2}$/.test(pair) ? pair : "",
    pairs: dui.pairs || dui.pairCodes || [],
    code: dui.code || "",
    quality: dui.quality || "",
    basePeriod: pred.basePeriod || "",
    pairRate: num(dui.rate120 != null ? dui.rate120 : dui.rate30, -1)
  };
}

/** 步骤1：只从首页取 ④二数合 */
async function fetchTwoHeweiHome() {
  const html = await httpGetText(ENSEMBLE_URL, 8000);
  const pendMatch = String(html).match(
    /<div class="card pend">([\s\S]*?)(?:<div class="card(?! pend)|$)/
  );
  const block = pendMatch ? pendMatch[1] : html;
  const two = extractTwoHeweiOnly(block);
  if (!two || !two.code) {
    throw new Error("首页未解析到 ④二数合尾中[xxxxx]：" + ENSEMBLE_URL);
  }
  const bm = block.match(/基准期\s*(\d+)\s*→\s*预测期\s*(\d+)/);
  return {
    two,
    trio: trioFromText(two.name),
    basePeriod: bm ? bm[1] : "",
    targetPeriod: bm ? bm[2] : "",
    source: ENSEMBLE_URL
  };
}

function trioFromText(text) {
  const s = String(text || "");
  // 长的先匹配，避免 千百十个 误吃 千百十
  if (/千百十个/.test(s)) return TRIO_DEFS.find((t) => t.id === "百十个"); // 四位不用于本三定；回退百十个
  for (const t of TRIO_DEFS) {
    if (t.re.test(s)) return t;
  }
  return TRIO_DEFS[0];
}

function posKeyFromKillName(name) {
  const s = String(name || "");
  if (/个位/.test(s)) return "shi";
  if (/十位/.test(s)) return "bai";
  if (/百位/.test(s)) return "qian";
  if (/千位/.test(s)) return "wan";
  return "";
}

function upsertPos(map, key, digit, rate, name, source) {
  if (!key || !POS_META[key] || !/^\d$/.test(digit)) return;
  const row = {
    key,
    digit,
    rate120: rate,
    name: name || POS_META[key].label + "位杀" + digit,
    source: source || ""
  };
  const old = map[key];
  if (!old || rateOf(row) > rateOf(old)) map[key] = row;
}

/** 三个位置里只取命中率最高的俩个 */
function pickTop2InTrio(posMap, trioKeys) {
  const list = (trioKeys || [])
    .map((k) => posMap[k])
    .filter(Boolean);
  list.sort((a, b) => {
    const d = rateOf(b) - rateOf(a);
    if (d !== 0) return d;
    return String(a.key).localeCompare(String(b.key));
  });
  const top = list.slice(0, 2);
  const picked = Object.create(null);
  top.forEach((row) => {
    picked[row.key] = row;
  });
  return { picked, ranked: list, top };
}

/** 步骤1：只取 ④二数合（定方向），其它一律不看 */
function extractTwoHeweiOnly(block) {
  let tm = String(block || "").match(
    /④\s*([^<]*二数合尾中\[(\d{4,6})\])\s*<em>近120期\s*([\d.]+)%,?<\/em>/
  );
  if (!tm) {
    tm = String(block || "").match(
      /④[^<\n]{0,50}二数合尾中\[(\d{4,6})\][\s\S]{0,80}?近120期\s*([\d.]+)%/
    );
  }
  if (!tm) tm = String(block || "").match(/二数合尾中\[(\d{4,6})\]/);
  if (!tm) return null;
  const code = tm[2] && /^\d{4,6}$/.test(tm[2]) ? tm[2] : tm[1];
  let rate = null;
  if (tm[3] != null) rate = Number(tm[3]);
  else if (tm[2] != null && !/^\d{4,6}$/.test(String(tm[2]))) rate = Number(tm[2]);
  const name =
    tm[1] && /二数合/.test(String(tm[1]))
      ? String(tm[1]).replace(/\s+/g, "")
      : "二数合尾中[" + code + "]";
  return { code, rate120: rate, name, source: "ensemble-html④" };
}

/**
 * 步骤2：已有方向后，扫下面（④ 之后的 killline/tags），
 * 并用同组 taskrow①②③ 补命中率；组外位一律丢弃。
 */
function scanBelowByTrio(block, trio) {
  const text = String(block || "");
  const scope = Object.create(null);
  (trio.keys || []).forEach((k) => {
    scope[k] = true;
  });

  const posMap = Object.create(null);
  const heweiCands = [];

  // ④ 在 HTML 中的位置：下面优先扫这段
  let belowIdx = text.search(/taskrow">④|④\s*[^<]*二数合尾中/);
  if (belowIdx < 0) belowIdx = text.search(/二数合尾中\[/);
  const below = belowIdx >= 0 ? text.slice(belowIdx) : text;
  const above = belowIdx >= 0 ? text.slice(0, belowIdx) : "";

  function ingestPos(pk, digit, rate, name, source) {
    if (!scope[pk]) return; // 无方向 / 组外 → 不收
    upsertPos(posMap, pk, digit, rate, name, source);
  }

  function ingestHewei(digit, rate, name, source, votes) {
    const tid = trioFromText(name).id;
    if (tid !== trio.id) return; // 只收同组合尾
    heweiCands.push({
      digit,
      rate120: rate,
      name,
      source,
      trioId: tid,
      votes: votes == null ? -1 : votes
    });
  }

  // 2a) 先扫④下面：killline / tags
  const kill = (below.match(/class="killline">([^<]+)/) ||
    text.match(/class="killline">([^<]+)/) ||
    [])[1] || "";
  kill.split(/[｜|]/).forEach((seg) => {
    const s = seg.trim();
    const posRe = /(千位|百位|十位|个位)杀(\d)/g;
    let pm;
    while ((pm = posRe.exec(s))) {
      const pk = posKeyFromKillName(pm[1] + "杀");
      ingestPos(pk, pm[2], -1, pm[1] + "杀" + pm[2], "below-killline");
    }
    const hm = s.match(/(千百十个|百十个|千百十|千百个|千十个)(?:合)?尾杀(\d)/);
    if (hm) ingestHewei(hm[2], null, hm[1] + "尾杀" + hm[2], "below-killline");
  });

  const tagRe = />([^<]*(?:千百十个|百十个|千百十|千百个|千十个)(?:合)?尾杀(\d))[^<]*<em>([^<]*)<\/em>/g;
  let m;
  while ((m = tagRe.exec(below.length > 20 ? below : text))) {
    const name = m[1].replace(/\s+/g, "");
    ingestHewei(m[2], null, name, "below-tag:" + m[3], num(String(m[3]).replace(/\D/g, ""), -1));
  }

  // 2b) 同组①②③补命中率（在④上面，但是同一四项；只收组内）
  const rowRe = /<div class="taskrow">([①②③④]\s*[^<]+)<em>近120期\s*([\d.]+)%,?<\/em>/g;
  while ((m = rowRe.exec(above || text))) {
    const mark = m[1];
    if (/^④/.test(mark.trim()) || /④\s/.test(mark)) continue;
    const body = mark.replace(/^[①②③④]\s*/, "").trim();
    const rate = Number(m[2]);
    if (/位杀/.test(body)) {
      const pk = posKeyFromKillName(body);
      const dm = body.match(/杀(\d)/);
      if (pk && dm) ingestPos(pk, dm[1], rate, body, "taskrow-rate");
    } else if (/合尾杀/.test(body)) {
      const dm = body.match(/合尾杀(\d)/);
      if (dm) ingestHewei(dm[1], rate, body, "taskrow③");
    }
  }

  // 若下面没扫到合尾，再允许整卡同组③
  if (!heweiCands.length) {
    const rowRe2 = /<div class="taskrow">([①②③④]\s*[^<]+)<em>近120期\s*([\d.]+)%,?<\/em>/g;
    while ((m = rowRe2.exec(text))) {
      const body = m[1].replace(/^[①②③④]\s*/, "").trim();
      const rate = Number(m[2]);
      if (!/合尾杀/.test(body)) continue;
      const dm = body.match(/合尾杀(\d)/);
      if (dm) ingestHewei(dm[1], rate, body, "taskrow③-fallback");
    }
  }

  let pair = "";
  const pm = kill.match(/除对数(\d{2})/) || below.match(/除对数(\d{2})/) || text.match(/除对数(\d{2})/);
  if (pm) pair = pm[1];

  return { posMap, heweiCands, pair, killline: kill };
}

function parsePendingHtml(html) {
  const text = String(html || "");
  const pendMatch = text.match(/<div class="card pend">([\s\S]*?)(?:<div class="card(?! pend)|$)/);
  const block = pendMatch ? pendMatch[1] : text;

  const bm = block.match(/基准期\s*(\d+)\s*→\s*预测期\s*(\d+)/);
  const title = ((block.match(/taskbox-title">([^<]+)/) || [])[1] || "").trim();

  // —— 步骤1：先二数合，定方向 ——
  const two = extractTwoHeweiOnly(block);
  if (!two || !two.code) {
    return {
      basePeriod: bm ? bm[1] : "",
      targetPeriod: bm ? bm[2] : "",
      two: null,
      trio: null,
      posMap: {},
      heweiCands: [],
      pair: "",
      killline: "",
      title,
      fetchVia: ENSEMBLE_URL,
      phase: "need-two"
    };
  }
  const trio = trioFromText(two.name || title || "");

  // —— 步骤2：有方向，再扫下面 ——
  const scanned = scanBelowByTrio(block, trio);

  return {
    basePeriod: bm ? bm[1] : "",
    targetPeriod: bm ? bm[2] : "",
    two,
    trio,
    posMap: scanned.posMap,
    heweiCands: scanned.heweiCands,
    pair: scanned.pair,
    killline: scanned.killline,
    title,
    fetchVia: ENSEMBLE_URL,
    phase: "two-then-below"
  };
}

function parseFromEnsembleState(state) {
  if (!state || typeof state !== "object") return null;
  const pending = Array.isArray(state.pending) ? state.pending[0] : null;
  const hold = state.displayHold && typeof state.displayHold === "object" ? state.displayHold : null;
  const wrap = pending || hold;
  if (!wrap) return null;
  const task4 = wrap.task4 || {};
  const items = Array.isArray(task4.items) ? task4.items : [];

  // 步骤1：先二数合
  let two = null;
  items.forEach((it) => {
    if (!it) return;
    const kind = String(it.kind || "");
    const name = String(it.name || "");
    const code = String(it.code == null ? "" : it.code).replace(/\D/g, "");
    if (kind === "trioAnyTwoTail" || /二数合尾中/.test(name)) {
      if (code.length >= 4) two = { code, rate120: rateOf(it), name, source: "ensemble-state④" };
    }
  });
  if (!two) return null;
  const trio = trioFromText(two.name || task4.trioLabel || "");
  const scope = Object.create(null);
  trio.keys.forEach((k) => {
    scope[k] = true;
  });

  // 步骤2：有方向再扫其它
  const posMap = Object.create(null);
  const heweiCands = [];
  items.forEach((it) => {
    if (!it) return;
    const kind = String(it.kind || "");
    const name = String(it.name || "");
    const code = String(it.code == null ? "" : it.code).replace(/\D/g, "");
    const rate = rateOf(it);
    if (kind === "position" || /位杀/.test(name)) {
      const pk = posKeyFromKillName(name);
      if (!scope[pk]) return;
      upsertPos(posMap, pk, code.slice(0, 1), rate, name, "ensemble-state");
    } else if (kind === "trioSumTail" || /合尾杀/.test(name)) {
      const digit = code.slice(0, 1);
      const tid = trioFromText(name || task4.trioLabel || "").id;
      if (tid !== trio.id) return;
      if (/^\d$/.test(digit)) {
        heweiCands.push({ digit, rate120: rate, name, source: "ensemble-state③", trioId: tid });
      }
    }
  });

  let pair = "";
  const snapItems = wrap.snapshot && Array.isArray(wrap.snapshot.items) ? wrap.snapshot.items : [];
  snapItems.forEach((it) => {
    if (!it) return;
    const name = String(it.name || "");
    const code = String(it.code == null ? "" : it.code).replace(/\D/g, "");
    if (it.kind === "duishu" || /除对数/.test(name)) {
      const p = code.slice(0, 2);
      if (/^\d{2}$/.test(p)) pair = p;
    }
  });

  return {
    basePeriod: wrap.basePeriod || "",
    targetPeriod: wrap.targetPeriod || "",
    two,
    trio,
    posMap,
    heweiCands,
    pair,
    title: task4.trioLabel || "",
    fetchVia: ENSEMBLE_STATE,
    phase: "two-then-below"
  };
}

function loadLocalDuishu(root) {
  const duiPath = path.join(root, "data/algorithm-projects/three-duishu/state.json");
  if (!fs.existsSync(duiPath)) return null;
  const dui = readJson(duiPath);
  const pay = (dui.current && dui.current.payload) || {};
  return {
    pair: String(pay.selectedPair || "").replace(/\D/g, "").slice(0, 2),
    pairs: pay.pairs || pay.pairCodes || [],
    code: pay.code || "",
    quality: pay.quality || "",
    basePeriod: (dui.current && dui.current.basePeriod) || "",
    targetPeriod: (dui.current && dui.current.targetPeriod) || ""
  };
}

function loadIndepHewei(root, trioId) {
  const heweiPath = path.join(root, "data/algorithm-projects/hewei/state.json");
  if (!fs.existsSync(heweiPath)) return [];
  const st = readJson(heweiPath);
  const pay = (st.current && st.current.payload) || {};
  const ind = pay.independentHeweiKills || {};
  const map = {
    百十个: ["qianBaiShi"],
    千百十: ["wanQianBai"],
    千百个: ["wanQianShi", "qianBaiGe"],
    千十个: ["wanBaiShi"]
  };
  const keys = map[trioId] || ["qianBaiShi"];
  const out = [];
  keys.forEach((k) => {
    const q = ind[k];
    if (!q) return;
    const digit = String(q.killDigit || q.primaryDigit || "").replace(/\D/g, "").slice(0, 1);
    if (!/^\d$/.test(digit)) return;
    out.push({
      digit,
      rate120: rateOf(q),
      name: q.label || trioId + "合尾",
      source: "hewei.independent." + k,
      trioId
    });
  });
  return out;
}

function mergeWeb(a, b) {
  if (!a) return b;
  if (!b) return a;
  const posMap = Object.create(null);
  [a.posMap, b.posMap].forEach((mp) => {
    Object.keys(mp || {}).forEach((k) => {
      const row = mp[k];
      if (row) upsertPos(posMap, k, row.digit, rateOf(row), row.name, row.source);
    });
  });
  const two = a.two && a.two.code ? a.two : b.two;
  const trio = trioFromText((two && two.name) || (a.trio && a.trio.id) || (b.trio && b.trio.id) || "");
  return {
    basePeriod: a.basePeriod || b.basePeriod || "",
    targetPeriod: a.targetPeriod || b.targetPeriod || "",
    two,
    trio,
    posMap,
    heweiCands: [].concat(a.heweiCands || [], b.heweiCands || []),
    pair: a.pair || b.pair || "",
    killline: a.killline || b.killline || "",
    title: a.title || b.title || "",
    fetchVia: [a.fetchVia, b.fetchVia].filter(Boolean).filter((x, i, arr) => arr.indexOf(x) === i).join("+")
  };
}

async function fetchEnsemble() {
  let fromState = null;
  try {
    const raw = await httpGetText(ENSEMBLE_STATE, 8000);
    fromState = parseFromEnsembleState(JSON.parse(raw));
  } catch (_e) {
    /* ignore */
  }
  const html = await httpGetText(ENSEMBLE_URL, 8000);
  const fromHtml = parsePendingHtml(html);
  const merged = mergeWeb(fromHtml, fromState);
  if (!merged.two || !merged.two.code) {
    throw new Error("未解析到 ④二数合尾中[xxxxx]：" + ENSEMBLE_URL);
  }
  merged.trio = trioFromText(merged.two.name || (merged.trio && merged.trio.id) || "");
  return merged;
}

/** 合尾：同组优先，取命中率最高 */
function pickBestHewei(cands, trioId) {
  const list = (cands || []).filter((c) => c && /^\d$/.test(c.digit));
  const same = list.filter((c) => c.trioId === trioId);
  const pool = same.length ? same : list;
  pool.sort((a, b) => {
    const d = rateOf(b) - rateOf(a);
    if (d !== 0) return d;
    return num(b.votes, -1) - num(a.votes, -1);
  });
  // 有胜率的压过无胜率
  const withRate = pool.filter((c) => rateOf(c) >= 0);
  return (withRate.length ? withRate : pool)[0] || null;
}

function buildAttack(opts) {
  const trio = opts.trio || TRIO_DEFS[0];
  const picked = opts.picked || {};
  const pair = String(opts.pair || "").replace(/\D/g, "").slice(0, 2);
  const heweiDigit = String(opts.heweiDigit || "").replace(/\D/g, "").slice(0, 1);
  const twoCode = String(opts.twoHewei || "").replace(/\D/g, "");

  let text = "";
  const pools = {};
  const excludes = {};
  trio.keys.forEach((k) => {
    const label = POS_META[k].label;
    const dig = picked[k] && picked[k].digit ? picked[k].digit : "";
    excludes[k] = dig;
    pools[k] = stripDigit(FULL_POOL, dig);
    text += label + pools[k];
  });
  text += "三定";
  if (twoCode) text += "二数合" + twoCode;
  if (/^\d{2}$/.test(pair)) text += "除对数" + pair;
  if (/^\d$/.test(heweiDigit)) text += "除" + trio.heweiTok + heweiDigit;
  text += "各";

  return {
    text,
    meta: {
      trioId: trio.id,
      heweiToken: trio.heweiTok,
      pair: /^\d{2}$/.test(pair) ? pair : "",
      excludes,
      pools,
      heweiExclude: heweiDigit,
      heweiRate: opts.heweiRate,
      heweiName: opts.heweiName || "",
      heweiSource: opts.heweiSource || "",
      twoHewei: twoCode,
      twoHeweiRate: opts.twoHeweiRate,
      twoHeweiName: opts.twoHeweiName || "",
      twoSource: opts.twoSource || "",
      pairSource: opts.pairSource || ""
    }
  };
}

function historyPairs(root, limit) {
  const duiPath = path.join(root, "data/algorithm-projects/three-duishu/state.json");
  if (!fs.existsSync(duiPath)) return [];
  const dui = readJson(duiPath);
  const rows = [];
  const push = (row) => {
    if (!row || !row.payload) return;
    rows.push({
      basePeriod: row.basePeriod || "",
      targetPeriod: row.targetPeriod || "",
      selectedPair: String(row.payload.selectedPair || ""),
      pairs: row.payload.pairs || row.payload.pairCodes || []
    });
  };
  push(dui.current);
  (dui.history || []).forEach(push);
  const seen = Object.create(null);
  const uniq = [];
  rows.forEach((row) => {
    const key = String(row.targetPeriod || row.basePeriod || "") + "|" + String(row.selectedPair || "");
    if (seen[key]) return;
    seen[key] = true;
    uniq.push(row);
  });
  return uniq.slice(0, Math.max(1, Number(limit) || 50));
}

function parseArgs(argv) {
  const out = {
    history: 0,
    outFile: path.join(__dirname, "当期攻击语.txt"),
    lineFile: path.join(__dirname, "攻击语一行.txt"),
    root: ""
  };
  for (let i = 2; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--history") out.history = Number(argv[++i] || 50);
    else if (a === "--out") out.outFile = path.resolve(argv[++i] || out.outFile);
    else if (a === "--root") out.root = path.resolve(argv[++i] || "");
    else if (a === "--stdout") {
      out.outFile = "";
      out.lineFile = "";
    } else if (a === "--help" || a === "-h") out.help = true;
  }
  return out;
}

function printHelp() {
  console.log(`抓四项转攻击语

① 二数合：${ENSEMBLE_URL} ④（定三位方向）
② 定位/合尾/对数：面板 ${PANEL_BASES[0]}/panel （密码登录 /state）
   - 组内三位置只排除命中率最高 2 位（从 0123456789 删）
   - 同组合尾命中率最高
   - 三对数本期排除
禁止写成 除十X除百Y`);
}

async function main() {
  const args = parseArgs(process.argv);
  if (args.help) {
    printHelp();
    return;
  }

  // ① 先首页二数合 → 方向
  const home = await fetchTwoHeweiHome();
  const trio = home.trio || trioFromText(home.two.name);

  // ② 面板：定位 + 合尾 + 对数
  const panel = await fetchPanelState();
  const pickedPanel = pickFromPanelState(panel.state, trio);
  const { picked, ranked, top } = pickTop2InTrio(pickedPanel.posMap || {}, trio.keys);
  const hewei = pickBestHewei(pickedPanel.heweiCands || [], trio.id);

  const pair = pickedPanel.pair || "";
  const pairSource = pair
    ? "面板三对数本期排除 @ " + panel.panelUrl
    : "";

  if (!pair) {
    console.error("面板未取到三对数本期排除");
  }

  const built = buildAttack({
    trio,
    picked,
    pair,
    heweiDigit: hewei ? hewei.digit : "",
    heweiRate: hewei ? rateOf(hewei) : null,
    heweiName: hewei ? hewei.name : "",
    heweiSource: hewei ? hewei.source + " @ " + panel.panelUrl : "",
    twoHewei: home.two.code,
    twoHeweiRate: rateOf(home.two),
    twoHeweiName: home.two.name,
    twoSource: (home.two.source || "") + " @ " + home.source,
    pairSource
  });

  const m = built.meta;
  const lines = [];
  lines.push("【抓四项转攻击语 · 可复制】");
  lines.push("流程: ①首页二数合定方向 → ②面板定位/合尾/对数（从0123456789删码）");
  lines.push(
    "基准期: " +
      (home.basePeriod || pickedPanel.basePeriod || "--") +
      " → 预测期: " +
      (home.targetPeriod || "--")
  );
  lines.push(
    "①二数合→方向: " +
      trio.id +
      " ｜ " +
      m.twoHewei +
      " (" +
      fmtRate(m.twoHeweiRate) +
      ") " +
      (m.twoHeweiName || "") +
      " ← " +
      m.twoSource
  );
  lines.push(
    "②面板组内顶2删码: " +
      trio.keys
        .map((k) => {
          const lab = POS_META[k].label;
          const row = picked[k];
          if (!row) return lab + "-/(满码)";
          return lab + "-" + row.digit + "(" + fmtRate(row) + ")";
        })
        .join(" ") +
      (ranked.length
        ? " ｜候选 " +
          ranked.map((r) => POS_META[r.key].label + r.digit + "@" + fmtRate(r)).join(",")
        : "")
  );
  lines.push(
    "合尾(面板命中率最高): 除" +
      m.heweiToken +
      (m.heweiExclude || "?") +
      " (" +
      fmtRate(m.heweiRate) +
      ") " +
      (m.heweiName || "") +
      " ← " +
      (m.heweiSource || "")
  );
  lines.push(
    "对数: 除对数" +
      (m.pair || "--") +
      " ← " +
      (pairSource || "--") +
      (pickedPanel.pairs && pickedPanel.pairs.length
        ? " 候选 " + pickedPanel.pairs.join("|")
        : "") +
      (pickedPanel.quality ? "｜" + pickedPanel.quality : "")
  );
  lines.push(
    "池子: " + trio.keys.map((k) => POS_META[k].label + m.pools[k]).join(" ")
  );
  lines.push("");
  lines.push(built.text);
  lines.push("");

  if (args.history > 0) {
    const root = findRunnerRoot(args.root);
    if (root) {
      lines.push("—— 近" + args.history + "期对数（本地备份）——");
      historyPairs(root, args.history).forEach((row, i) => {
        lines.push(
          String(i + 1).padStart(2, "0") +
            ". " +
            (row.targetPeriod || row.basePeriod || "?") +
            " 排除 " +
            (row.selectedPair || "--") +
            " 候选 " +
            (row.pairs || []).join("|")
        );
      });
      lines.push("");
    }
  }

  if (!m.twoHewei) process.exitCode = 3;
  if (!m.pair) process.exitCode = 4;
  if (!m.heweiExclude) process.exitCode = 5;
  if (!top || top.length < 2) {
    console.error("组内定位不足2个");
    process.exitCode = 6;
  }
  // 防旧口径：攻击语里不允许出现 除十/除百/除千/除个 + 单码
  if (/除[千百十个]\d/.test(built.text)) {
    console.error("攻击语含除位写法，已拒绝（必须从池子删码）");
    process.exitCode = 7;
  }

  const body = lines.join("\n");
  if (args.outFile) fs.writeFileSync(args.outFile, body, "utf8");
  if (args.lineFile) {
    fs.writeFileSync(args.lineFile, built.text + "\n", "utf8");
    try {
      fs.writeFileSync(path.join(__dirname, "attack-three-line.txt"), built.text + "\n", "utf8");
    } catch (_e) {}
  }
  console.log(body);
  if (args.outFile) console.log("已写入: " + args.outFile);
  if (args.lineFile) console.log("可复制一行: " + args.lineFile);
}

main().catch((e) => {
  console.error(e && e.stack ? e.stack : e);
  process.exit(1);
});
