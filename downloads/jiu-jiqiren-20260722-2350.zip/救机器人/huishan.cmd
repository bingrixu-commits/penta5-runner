﻿@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo ERROR: node not found. Install Node.js and add to PATH.
  pause
  exit /b 1
)
node "%~dp0本机回删.js" --out
echo.
pause
