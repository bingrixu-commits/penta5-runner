﻿@echo off
chcp 65001 >nul
cd /d "%~dp0"
title grab-four-ding
echo ========================================
echo   抓四定 - 攻击语（本机·单独）
echo ========================================
echo.
where node >nul 2>nul
if errorlevel 1 (
  echo [ERROR] 未找到 node。请安装 Node.js
  pause
  exit /b 1
)
node "%~dp0抓四定转攻击语.js"
if errorlevel 1 (
  echo [ERROR] 抓取失败
  pause
  exit /b 1
)
if exist "%~dp0攻击语一行-四定.txt" (
  type "%~dp0攻击语一行-四定.txt" | clip
  echo.
  echo 已复制四定攻击语到剪贴板
)
echo.
pause
