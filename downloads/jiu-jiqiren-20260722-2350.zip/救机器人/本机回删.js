#!/usr/bin/env node
/**
 * 本机回删工具
 *
 * 数据：每次先从阿里云拉 200 期落到本机 → 本机生成 → 扫这 200 期命中就删 → 剩到 498 停
 * 例：历史开过 485x，剩余有 485 → 删 485；删到剩 498 立刻停
 *
 *   node 本机回删.js --out              # 默认：先阿里云刷新本地，再回删
 *   node 本机回删.js --offline --out    # 仅调试：不刷新，硬读本地（可能过期）
 */
"use strict";

const fs = require("fs");
const path = require("path");
const http = require("http");
const vm = require("vm");

const DIR = __dirname;
const HIST_FILE = path.join(DIR, "开奖历史.json");
const ATTACK_LINE = path.join(DIR, "攻击语一行.txt");
const OUT_TXT = path.join(DIR, "回删结果.txt");
const OUT_TXT_1 = path.join(DIR, "回删结果-第1批.txt");
const OUT_TXT_2 = path.join(DIR, "回删结果-第2批.txt");
const OUT_JSON = path.join(DIR, "回删结果.json");
const HIST_LIMIT = 200;
/** 投注端一次贴不完：前 300 一批，其余第二批 */
const BATCH1_SIZE = 300;
const PANEL_PASSWORD = process.env.PANEL_PASSWORD || "147258";
// 数据在阿里云：优先公网面板（RDS），本机面板作备援（内存里也是同一份 RDS）
const PANEL_BASES = (
  process.env.PANEL_BASES ||
  "http://8.210.5.221:3001,http://127.0.0.1:3001"
)
  .split(",")
  .map((s) => s.trim())
  .filter(Boolean);

function findConvertJs() {
  const cands = [
    path.join(DIR, "txt_attack_convert.js"), // 本目录自带，部署锁定
    path.resolve(DIR, "../../penta5-runner/txt_attack_convert.js"),
    path.resolve(DIR, "../penta5-runner/txt_attack_convert.js"),
    "/root/penta5-runner/txt_attack_convert.js",
    path.resolve(process.cwd(), "penta5-runner/txt_attack_convert.js")
  ];
  for (const p of cands) if (fs.existsSync(p)) return p;
  return null;
}

function loadApi() {
  const file = findConvertJs();
  if (!file) throw new Error("未找到 txt_attack_convert.js");
  const code = fs.readFileSync(file, "utf8");
  const sb = { console, module: { exports: {} }, exports: {}, require };
  sb.global = sb;
  vm.runInNewContext(code, sb, { filename: file });
  const api = sb.global.Penta5AttackTxtConvert;
  if (!api || typeof api.convertThreeDingHistoryHitDelete !== "function") {
    throw new Error("转换库未导出 convertThreeDingHistoryHitDelete");
  }
  return { api, file };
}

function httpJson(url, opts) {
  opts = opts || {};
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    const body = opts.body ? JSON.stringify(opts.body) : null;
    const req = http.request(
      {
        hostname: u.hostname,
        port: u.port || (u.protocol === "https:" ? 443 : 80),
        path: u.pathname + u.search,
        method: opts.method || "GET",
        headers: Object.assign(
          { Accept: "application/json" },
          body
            ? { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(body) }
            : {},
          opts.headers || {}
        ),
        timeout: opts.timeout || 120000
      },
      (res) => {
        let buf = "";
        res.setEncoding("utf8");
        res.on("data", (c) => (buf += c));
        res.on("end", () => {
          let data = null;
          try {
            data = JSON.parse(buf);
          } catch (_e) {
            data = { raw: buf.slice(0, 300) };
          }
          if (res.statusCode && res.statusCode >= 400) {
            const msg =
              (data && (data.error || data.message || data.reason)) || buf.slice(0, 160);
            reject(new Error("HTTP " + res.statusCode + " " + url + " :: " + msg));
            return;
          }
          resolve({ status: res.statusCode, headers: res.headers, data });
        });
      }
    );
    req.on("error", reject);
    req.on("timeout", () => {
      req.destroy();
      reject(new Error("timeout " + url));
    });
    if (body) req.write(body);
    req.end();
  });
}

function cookieFromSetCookie(setCookie) {
  if (!setCookie) return "";
  const arr = Array.isArray(setCookie) ? setCookie : [setCookie];
  return arr
    .map((s) => String(s).split(";")[0])
    .filter(Boolean)
    .join("; ");
}

/** 从阿里云端（经面板 /converter-history）拉 200 期，落到本机文件 */
async function fetchAliyunHistory200(base) {
  const root = String(base || "").replace(/\/$/, "");
  const login = await httpJson(root + "/login", {
    method: "POST",
    body: { password: PANEL_PASSWORD },
    timeout: 15000
  });
  const cookie = cookieFromSetCookie(login.headers && login.headers["set-cookie"]);
  const resp = await httpJson(root + "/converter-history?limit=" + HIST_LIMIT, {
    timeout: 120000,
    headers: cookie ? { Cookie: cookie } : {}
  });
  const data = resp.data || {};
  if (data.ok === false) {
    throw new Error(data.error || data.reason || "converter-history not ok");
  }
  const history = Array.isArray(data.history) ? data.history : [];
  if (history.length < HIST_LIMIT) {
    throw new Error(
      "阿里云历史不足 " + HIST_LIMIT + " 期，当前 " + history.length + " @ " + root
    );
  }
  return {
    history: history.slice(0, HIST_LIMIT),
    source: root,
    sharedHistorySource: data.sharedHistorySource || "rds",
    sharedHistoryRdsLatestPeriod: data.sharedHistoryRdsLatestPeriod || "",
    refreshedFromRds: !!data.refreshedFromRds,
    syncedAt: data.sharedHistorySyncedAt || new Date().toISOString()
  };
}

async function syncAliyunToLocal() {
  const errors = [];
  for (const base of PANEL_BASES) {
    try {
      const pack = await fetchAliyunHistory200(base);
      fs.writeFileSync(
        HIST_FILE,
        JSON.stringify(
          {
            updatedAt: pack.syncedAt,
            source: pack.source,
            sharedHistorySource: pack.sharedHistorySource,
            sharedHistoryRdsLatestPeriod: pack.sharedHistoryRdsLatestPeriod,
            refreshedFromRds: pack.refreshedFromRds,
            limit: HIST_LIMIT,
            history: pack.history
          },
          null,
          2
        ),
        "utf8"
      );
      return pack;
    } catch (e) {
      errors.push(base + " → " + (e && e.message ? e.message : e));
    }
  }
  throw new Error("从阿里云拉历史失败（" + HIST_LIMIT + "期）：\n" + errors.join("\n"));
}

function loadLocalHistory() {
  if (!fs.existsSync(HIST_FILE)) {
    throw new Error("没有本地 开奖历史.json，请先 --sync 从阿里云拉到本机");
  }
  const raw = JSON.parse(fs.readFileSync(HIST_FILE, "utf8"));
  const history = Array.isArray(raw.history) ? raw.history : [];
  if (history.length < 1) throw new Error("本地 开奖历史.json 为空");
  return {
    history: history.slice(0, HIST_LIMIT),
    source: raw.source || HIST_FILE,
    sharedHistorySource: raw.sharedHistorySource || "local-file",
    sharedHistoryRdsLatestPeriod: raw.sharedHistoryRdsLatestPeriod || "",
    updatedAt: raw.updatedAt || ""
  };
}

function parseArgs(argv) {
  const out = { text: "", out: false, sync: true, offline: false, help: false };
  for (let i = 2; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--text") out.text = String(argv[++i] || "");
    else if (a === "--out") out.out = true;
    else if (a === "--sync") out.sync = true;
    else if (a === "--offline") {
      out.offline = true;
      out.sync = false;
    } else if (a === "--help" || a === "-h") out.help = true;
    else if (!a.startsWith("-") && !out.text) out.text = a;
  }
  return out;
}

function loadAttackText(cliText) {
  if (cliText && String(cliText).trim()) return String(cliText).trim();
  if (fs.existsSync(ATTACK_LINE)) {
    const t = fs.readFileSync(ATTACK_LINE, "utf8").trim();
    if (t) return t;
  }
  const f = path.join(DIR, "当期攻击语.txt");
  if (fs.existsSync(f)) {
    const lines = fs.readFileSync(f, "utf8").split(/\r?\n/);
    const hit = lines.find((l) => /三定/.test(l) && /各/.test(l));
    if (hit) return hit.trim();
  }
  throw new Error("无攻击语：请先跑抓码，或 --text 传入");
}

async function main() {
  const args = parseArgs(process.argv);
  if (args.help) {
    console.log(`本机回删

  node 本机回删.js --out            # 默认每次：阿里云刷新本地 → 再回删（防过期乱掉）
  node 本机回删.js --offline --out  # 仅调试：不刷新，硬读本地

数据在阿里云；每次先落到本机，回删计算只读这份本地。本期起往后扫 ${HIST_LIMIT} 期，同样数字删。`);
    return;
  }

  const attack = loadAttackText(args.text);
  console.log("【本机回删】本机生成 → 扫云端200期命中删 → 剩498停");
  console.log("攻击语: " + attack);

  let pack;
  if (args.offline) {
    pack = loadLocalHistory();
    console.log(
      "⚠ --offline 未刷新，可能过期: " +
        HIST_FILE +
        (pack.updatedAt ? " @ " + pack.updatedAt : "")
    );
  } else {
    console.log("从阿里云拉 " + HIST_LIMIT + " 期到本机…");
    pack = await syncAliyunToLocal();
    console.log(
      "已写入: " +
        HIST_FILE +
        " ← " +
        pack.source +
        " (" +
        (pack.sharedHistorySource || "rds") +
        ")" +
        (pack.sharedHistoryRdsLatestPeriod
          ? " rdsLatest=" + pack.sharedHistoryRdsLatestPeriod
          : "")
    );
  }

  const { api, file } = loadApi();
  console.log("转换库: " + file);
  const latest = pack.history[0] || {};
  console.log(
    "回删用本地历史: " +
      pack.history.length +
      " 期，本期起 " +
      (latest.period || "?") +
      " " +
      JSON.stringify(latest.numbers || [])
  );

  const result = api.convertThreeDingHistoryHitDelete(attack, pack.history, {});
  if (!result || result.ok === false) {
    console.error("回删失败: " + ((result && result.message) || "unknown"));
    process.exit(2);
  }

  const codes = result.codes || result.tokens || [];
  const list = Array.isArray(codes) ? codes.map(String) : [];
  // 正式投注格式：空位 x、逗号隔开、末尾「各」（如 002x,004x,...各）
  let copyParts = result.copyParts;
  if (
    (!copyParts || !copyParts.part1Text) &&
    typeof api.threeDingCopyParts === "function"
  ) {
    copyParts = api.threeDingCopyParts(
      list,
      BATCH1_SIZE,
      result.comboName || result.combo || "千百十"
    );
  }
  const batch1 = (copyParts && copyParts.part1Tokens) || list.slice(0, BATCH1_SIZE);
  const batch2 = (copyParts && copyParts.part2Tokens) || list.slice(BATCH1_SIZE);
  const text1 =
    (copyParts && copyParts.part1Text) ||
    (typeof api.formatThreeDingGeList === "function"
      ? api.formatThreeDingGeList(batch1, null, result.comboName || "千百十")
      : batch1.join(","));
  const text2 =
    (copyParts && copyParts.part2Text) ||
    (batch2.length
      ? typeof api.formatThreeDingGeList === "function"
        ? api.formatThreeDingGeList(batch2, null, result.comboName || "千百十")
        : batch2.join(",")
      : "");
  const textOut =
    result.text ||
    result.attackText ||
    (typeof api.formatThreeDingGeList === "function"
      ? api.formatThreeDingGeList(list, null, result.comboName || "千百十")
      : list.join(","));
  const samples = Array.isArray(result.hitSamples) ? result.hitSamples.join(" ") : "";
  const summary = [
    "【本机回删结果 · 本机生成 → 扫云端200期 → 剩498停】",
    "攻击语: " + attack,
    "历史文件: " + HIST_FILE,
    "拉取来源: " + pack.source + " / " + (pack.sharedHistorySource || "rds"),
    "历史期数: " + pack.history.length + "（本期 " + (latest.period || "?") + "）",
    "本机排除后: " + (result.afterFilter != null ? result.afterFilter : "--"),
    "已删命中: " + (result.deletedUnique != null ? result.deletedUnique : "--"),
    "扫期: " + (result.scanned != null ? result.scanned : "--"),
    "现剩: " + (result.count != null ? result.count : list.length) +
      (result.stoppedAtFloor ? "（已到498停）" : ""),
    "格式: 空位x + 逗号隔开 + 各收尾；分批 第1批 " +
      batch1.length +
      " → 回删结果-第1批.txt；第2批 " +
      batch2.length +
      " → 回删结果-第2批.txt",
    samples ? "命中样例: " + samples : "",
    "说明: " + (result.note || result.label || ""),
    "",
    "—— 第1批（先复制这批）——",
    text1,
    "",
    "—— 第2批（第一批打完再复制）——",
    text2 || "（无，全部已在第1批）",
    "",
    "—— 全部 ——",
    textOut,
    ""
  ]
    .filter((line, i, arr) => line !== "" || (i > 0 && arr[i - 1] !== ""))
    .join("\n");

  console.log(summary);

  if (args.out) {
    fs.writeFileSync(OUT_TXT, summary, "utf8");
    fs.writeFileSync(OUT_TXT_1, text1 + (text1 ? "\n" : ""), "utf8");
    fs.writeFileSync(OUT_TXT_2, text2 + (text2 ? "\n" : ""), "utf8");
    fs.writeFileSync(
      OUT_JSON,
      JSON.stringify(
        {
          ok: true,
          attack,
          historyCount: pack.history.length,
          historyFile: HIST_FILE,
          historySource: pack.source,
          latestPeriod: latest.period || "",
          comboName: result.comboName || "",
          batch1Size: BATCH1_SIZE,
          batch1Text: text1,
          batch2Text: text2,
          allText: textOut,
          batch1: batch1,
          batch2: batch2,
          result: {
            label: result.label,
            note: result.note,
            afterFilter: result.afterFilter,
            deletedUnique: result.deletedUnique,
            scanned: result.scanned,
            remainFloor: result.remainFloor != null ? result.remainFloor : 498,
            stoppedAtFloor: !!result.stoppedAtFloor,
            hitSamples: result.hitSamples || [],
            count: result.count != null ? result.count : list.length
          },
          codes: list
        },
        null,
        2
      ),
      "utf8"
    );
    console.log("已写入: " + OUT_TXT);
    console.log("已写入: " + OUT_TXT_1 + "（" + batch1.length + " 个，跑完后已可复制）");
    console.log("已写入: " + OUT_TXT_2 + "（" + batch2.length + " 个）");
    console.log("已写入: " + OUT_JSON);
  } else {
    console.log("（未写结果文件；需要时加 --out）");
  }
}

main().catch((e) => {
  console.error(e && e.stack ? e.stack : e);
  process.exit(1);
});
