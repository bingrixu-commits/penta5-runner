﻿@echo off
cd /d "%~dp0"
title paste-board
echo ========================================
echo  Paste board
echo  Keep this window OPEN
echo  Browser: http://127.0.0.1:3792/
echo ========================================
echo.
where node >nul 2>nul
if errorlevel 1 (
  echo ERROR: Node.js not found. Install Node.js first.
  echo.
  pause
  goto :keep
)
if not exist "%~dp0paste-board.js" (
  echo ERROR: paste-board.js missing in this folder
  dir /b "%~dp0*.js"
  echo.
  pause
  goto :keep
)
echo Starting paste-board.js ...
node "%~dp0paste-board.js"
set ERR=%ERRORLEVEL%
echo.
echo paste-board exited code %ERR%
echo.
pause
goto :eof

:keep
echo.
echo Window stays open. Close manually when done.
cmd /k
