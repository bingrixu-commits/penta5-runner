﻿@echo off
cd /d "%~dp0"
title paste-board
echo Paste board (keep window open)
echo http://127.0.0.1:3792/
echo.
where node >nul 2>nul
if errorlevel 1 (
  echo ERROR: node not found
  pause
  exit /b 1
)
node "%~dp0paste-board.js"
echo.
pause
