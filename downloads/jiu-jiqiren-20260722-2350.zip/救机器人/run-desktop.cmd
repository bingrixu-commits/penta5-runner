﻿@echo off
chcp 65001 >nul
cd /d "%~dp0"
title desktop-3791
echo ========================================
echo   Desktop convert :1271 port 3791
echo   Keep this window OPEN
echo ========================================
echo.
where node >nul 2>nul
if errorlevel 1 (
  echo [ERROR] node not found. Install Node.js and Add to PATH
  pause
  exit /b 1
)
if not exist "%~dp0desktop-server.js" (
  echo [ERROR] missing desktop-server.js
  pause
  exit /b 1
)
if not exist "%~dp0txt_attack_convert.js" (
  echo [ERROR] missing txt_attack_convert.js
  pause
  exit /b 1
)
echo Starting http://127.0.0.1:3791/
echo DO NOT close this black window.
echo.
node "%~dp0desktop-server.js"
echo.
echo Server stopped.
pause
