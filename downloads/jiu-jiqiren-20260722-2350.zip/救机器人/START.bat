﻿@echo off
chcp 65001 >nul
cd /d "%~dp0"
title huishan-498
echo 一键回删：阿里云200 → 前望后扫 → 剩498停 → 分两批复制
echo.
where node >nul 2>nul
if errorlevel 1 (
  echo 未找到 node，请先安装 Node.js
  pause
  exit /b 1
)
node "%~dp0本机回删.js" --out
if errorlevel 1 (
  echo [ERROR] 回删失败
  pause
  exit /b 1
)
echo.
if exist "%~dp0回删结果-第1批.txt" (
  type "%~dp0回删结果-第1批.txt" | clip
  echo 第1批已复制到剪贴板（约前300个）→ 先去投注软件 Ctrl+V
  echo 第2批文件: 回删结果-第2批.txt （第1批打完后打开全选复制再贴）
) else (
  echo 未找到分批文件
)
echo.
pause
