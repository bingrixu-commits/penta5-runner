#!/usr/bin/env node
/**
 * 粘贴板：粘贴命令调度抓/回删；空或「停」=停工；命令不变则新一期自动再跑。
 *
 *   node 粘贴板.js
 * 浏览器打开 http://127.0.0.1:3792/
 */
"use strict";

const fs = require("fs");
const path = require("path");
const http = require("http");
const { spawn } = require("child_process");
const { URL } = require("url");

const DIR = __dirname;
const PORT = Number(process.env.PASTE_PORT || 3792);
const HTML_FILE = fs.existsSync(path.join(DIR, "粘贴板.html"))
  ? path.join(DIR, "粘贴板.html")
  : path.join(DIR, "paste-board.html");
const CMD_FILE = path.join(DIR, "命令.txt");
const STATE_FILE = path.join(DIR, "粘贴板状态.json");
const PANEL_PASSWORD = process.env.PANEL_PASSWORD || "147258";
const PANEL_BASES = (
  process.env.PANEL_BASES ||
  "http://8.210.5.221:3001,http://127.0.0.1:3001"
)
  .split(",")
  .map((s) => s.trim())
  .filter(Boolean);
const POLL_MS = Number(process.env.PASTE_POLL_MS || 20000);

const state = {
  command: "", // grab | grab4 | huishan | both | ""
  commandRaw: "",
  commandDisplay: "（停工）",
  running: false,
  watchPeriod: "",
  lastPeriodRun: "",
  lastSummary: "",
  lastError: "",
  lastAttackText: "",
  lastAttackKind: "",
  lastAttackAt: "",
  logs: [],
  startedAt: new Date().toISOString()
};

function log(msg) {
  const line = "[" + new Date().toLocaleTimeString("zh-CN", { hour12: false }) + "] " + msg;
  state.logs.push(line);
  if (state.logs.length > 80) state.logs = state.logs.slice(-80);
  console.log(line);
  saveState();
}

function saveState() {
  try {
    fs.writeFileSync(
      STATE_FILE,
      JSON.stringify(
        {
          command: state.command,
          commandRaw: state.commandRaw,
          watchPeriod: state.watchPeriod,
          lastPeriodRun: state.lastPeriodRun,
          lastSummary: state.lastSummary,
          updatedAt: new Date().toISOString()
        },
        null,
        2
      ),
      "utf8"
    );
  } catch (_e) {}
}

function normalizeCommand(raw) {
  let s = String(raw == null ? "" : raw)
    .replace(/^\uFEFF/, "")
    .trim()
    .replace(/\s+/g, "");
  if (!s || s === "停" || s === "停止" || s === "stop" || s === "idle") {
    return { key: "", raw: s || "", display: "（停工）" };
  }
  if (
    s === "抓" ||
    s === "运行" ||
    s === "抓码" ||
    s === "攻击语" ||
    /^抓攻击/.test(s)
  ) {
    return { key: "grab", raw: s, display: "抓（三定攻击语）" };
  }
  if (s === "抓四定" || s === "四定" || s === "运行四定") {
    return { key: "grab4", raw: s, display: "抓（四定攻击语）" };
  }
  if (s === "回删" || s === "一键回删" || s === "huishan") {
    return { key: "huishan", raw: s, display: "回删" };
  }
  if (
    s === "抓+回删" ||
    s === "抓回删" ||
    s === "全自动" ||
    s === "抓＋回删"
  ) {
    return { key: "both", raw: s, display: "抓+回删" };
  }
  return { key: null, raw: s, display: "未知命令" };
}

function runNode(script, args) {
  return new Promise((resolve, reject) => {
    const child = spawn(process.execPath, [path.join(DIR, script)].concat(args || []), {
      cwd: DIR,
      windowsHide: true,
      env: process.env
    });
    let out = "";
    let err = "";
    child.stdout.on("data", (d) => {
      out += d.toString("utf8");
    });
    child.stderr.on("data", (d) => {
      err += d.toString("utf8");
    });
    child.on("error", reject);
    child.on("close", (code) => {
      if (code === 0) resolve({ out, err });
      else
        reject(
          new Error(
            script +
              " 退出码 " +
              code +
              (err || out ? "\n" + (err || out).slice(-500) : "")
          )
        );
    });
  });
}

function clipFile(file) {
  return new Promise((resolve) => {
    if (process.platform !== "win32" || !fs.existsSync(file)) {
      resolve(false);
      return;
    }
    const child = spawn(
      process.env.ComSpec || "cmd.exe",
      ["/c", "type", file, "|", "clip"],
      { cwd: DIR, windowsHide: true, shell: true }
    );
    child.on("close", () => resolve(true));
    child.on("error", () => resolve(false));
  });
}

function readLineFile(file) {
  if (!fs.existsSync(file)) return "";
  const lines = fs
    .readFileSync(file, "utf8")
    .trim()
    .split(/\r?\n/)
    .map((s) => s.trim())
    .filter(Boolean);
  return lines.length ? lines[lines.length - 1] : "";
}

function setAttackResult(kind, text) {
  state.lastAttackKind = kind || "";
  state.lastAttackText = String(text || "").trim();
  state.lastAttackAt = new Date().toLocaleString("zh-CN", { hour12: false });
  saveState();
}

function loadAttackFromDisk() {
  const fourEn = path.join(DIR, "attack-four-line.txt");
  const fourZh = path.join(DIR, "攻击语一行-四定.txt");
  const threeEn = path.join(DIR, "attack-three-line.txt");
  const threeZh = path.join(DIR, "攻击语一行.txt");
  const four = readLineFile(fourEn) || readLineFile(fourZh);
  const three = readLineFile(threeEn) || readLineFile(threeZh);
  let fourM = 0;
  let threeM = 0;
  try {
    if (fs.existsSync(fourEn)) fourM = fs.statSync(fourEn).mtimeMs;
    else if (fs.existsSync(fourZh)) fourM = fs.statSync(fourZh).mtimeMs;
    if (fs.existsSync(threeEn)) threeM = fs.statSync(threeEn).mtimeMs;
    else if (fs.existsSync(threeZh)) threeM = fs.statSync(threeZh).mtimeMs;
  } catch (_e) {}
  if (four && (!three || fourM >= threeM)) setAttackResult("四定", four);
  else if (three) setAttackResult("三定", three);
}

async function doGrab() {
  log("执行：抓四项转攻击语（三定）");
  await runNode("grab-three.js", ["--history", "20"]);
  const lineFile = path.join(DIR, "攻击语一行.txt");
  const lineFileEn = path.join(DIR, "attack-three-line.txt");
  const line = readLineFile(lineFile);
  if (line) fs.writeFileSync(lineFileEn, line + "\n", "utf8");
  await clipFile(fs.existsSync(lineFileEn) ? lineFileEn : lineFile);
  setAttackResult("三定", line);
  state.lastSummary = line ? "三定完成（下方已显示）" : "三定抓取完成";
  log(state.lastSummary);
}

async function doGrabFour() {
  log("执行：抓四定转攻击语");
  await runNode("grab-four.js", []);
  const lineFile = path.join(DIR, "attack-four-line.txt");
  const lineFileZh = path.join(DIR, "攻击语一行-四定.txt");
  const line = readLineFile(lineFile) || readLineFile(lineFileZh);
  await clipFile(fs.existsSync(lineFile) ? lineFile : lineFileZh);
  setAttackResult("四定", line);
  state.lastSummary = line ? "四定完成（下方已显示）" : "四定抓取完成";
  log(state.lastSummary);
}

async function doHuishan() {
  log("执行：本机回删");
  await runNode("本机回删.js", ["--out"]);
  const b1 = path.join(DIR, "回删结果-第1批.txt");
  await clipFile(b1);
  let n1 = 0;
  let n2 = 0;
  try {
    if (fs.existsSync(b1)) {
      const t = fs.readFileSync(b1, "utf8").replace(/各\s*$/, "").trim();
      n1 = t ? t.split(",").filter(Boolean).length : 0;
    }
    const b2 = path.join(DIR, "回删结果-第2批.txt");
    if (fs.existsSync(b2)) {
      const t2 = fs.readFileSync(b2, "utf8").replace(/各\s*$/, "").trim();
      n2 = t2 ? t2.split(",").filter(Boolean).length : 0;
    }
  } catch (_e) {}
  state.lastSummary =
    "回删完成；第1批已复制" +
    (n1 ? "（" + n1 + "）" : "") +
    (n2 ? "，第2批在 回删结果-第2批.txt（" + n2 + "）" : "");
  log(state.lastSummary);
}

async function runCommand(reason) {
  if (!state.command) {
    log("停工中，跳过（" + reason + "）");
    return;
  }
  if (state.running) {
    log("上一次还在跑，跳过（" + reason + "）");
    return;
  }
  state.running = true;
  state.lastError = "";
  saveState();
  try {
    log("开始执行「" + state.commandDisplay + "」· " + reason);
    if (state.command === "grab" || state.command === "both") await doGrab();
    if (state.command === "grab4") await doGrabFour();
    if (state.command === "huishan" || state.command === "both") await doHuishan();
    if (state.watchPeriod) state.lastPeriodRun = state.watchPeriod;
    log("本轮结束");
  } catch (e) {
    state.lastError = e && e.message ? e.message : String(e);
    state.lastSummary = "失败: " + state.lastError.split("\n")[0];
    log(state.lastSummary);
  } finally {
    state.running = false;
    saveState();
  }
}

function setCommand(raw, runNow) {
  const n = normalizeCommand(raw);
  if (n.key === null) {
      return { ok: false, message: "未知命令：「" + n.raw + "」。请用：抓 / 抓四定 / 回删 / 抓+回删 / 停" };
  }
  const prev = state.command;
  state.command = n.key;
  state.commandRaw = n.raw;
  state.commandDisplay = n.display;
  try {
    fs.writeFileSync(CMD_FILE, (n.raw || "停") + "\n", "utf8");
  } catch (_e) {}
  saveState();
  if (!n.key) {
    log("已停工");
    return { ok: true, ...publicStatus() };
  }
  log("命令生效: " + n.display + (prev === n.key ? "（未更换）" : "（已更换）"));
  if (runNow) {
    setImmediate(() => runCommand("手动生效"));
  }
  return { ok: true, ...publicStatus() };
}

function publicStatus() {
  // 每次状态查询也刷新磁盘上的最新攻击语，避免漏显示
  try {
    loadAttackFromDisk();
  } catch (_e) {}
  return {
    ok: true,
    command: state.command,
    commandRaw: state.commandRaw,
    commandDisplay: state.commandDisplay,
    running: state.running,
    watchPeriod: state.watchPeriod,
    lastPeriodRun: state.lastPeriodRun,
    lastSummary: state.lastSummary,
    lastError: state.lastError,
    lastAttackText: state.lastAttackText,
    lastAttackKind: state.lastAttackKind,
    lastAttackAt: state.lastAttackAt,
    logs: state.logs.slice(-40)
  };
}

function httpJson(url, opts) {
  opts = opts || {};
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    const body = opts.body ? JSON.stringify(opts.body) : null;
    const req = http.request(
      {
        hostname: u.hostname,
        port: u.port || 80,
        path: u.pathname + u.search,
        method: opts.method || "GET",
        headers: Object.assign(
          { Accept: "application/json" },
          body
            ? { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(body) }
            : {},
          opts.headers || {}
        ),
        timeout: opts.timeout || 30000
      },
      (res) => {
        let buf = "";
        res.setEncoding("utf8");
        res.on("data", (c) => (buf += c));
        res.on("end", () => {
          let data = null;
          try {
            data = JSON.parse(buf);
          } catch (_e) {
            data = { raw: buf.slice(0, 200) };
          }
          resolve({ status: res.statusCode || 0, headers: res.headers, data });
        });
      }
    );
    req.on("error", reject);
    req.on("timeout", () => {
      req.destroy();
      reject(new Error("timeout"));
    });
    if (body) req.write(body);
    req.end();
  });
}

function cookieFromSetCookie(setCookie) {
  const arr = Array.isArray(setCookie) ? setCookie : setCookie ? [setCookie] : [];
  return arr
    .map((s) => String(s).split(";")[0])
    .filter(Boolean)
    .join("; ");
}

async function fetchPanelPeriod() {
  let lastErr = null;
  for (const base of PANEL_BASES) {
    try {
      const login = await httpJson(base.replace(/\/$/, "") + "/login", {
        method: "POST",
        body: { password: PANEL_PASSWORD }
      });
      const cookie = cookieFromSetCookie(login.headers && login.headers["set-cookie"]);
      const st = await httpJson(base.replace(/\/$/, "") + "/state", {
        headers: cookie ? { Cookie: cookie } : {}
      });
      const data = st.data || {};
      const latestRec = data.latestRecord || data.latest || {};
      const period =
        data.sharedHistoryLatestPeriod ||
        data.sharedHistoryRdsLatestPeriod ||
        data.latestPeriod ||
        data.currentPeriod ||
        data.period ||
        latestRec.period ||
        latestRec.uid ||
        (data.lastSync && (data.lastSync.latestPeriod || data.lastSync.period)) ||
        (Array.isArray(data.history) && data.history[0] && (data.history[0].period || data.history[0].uid)) ||
        "";
      if (period) return String(period);
      lastErr = new Error("面板无期号 @" + base);
    } catch (e) {
      lastErr = e;
    }
  }
  throw lastErr || new Error("面板不可用");
}

async function pollLoop() {
  try {
    const period = await fetchPanelPeriod();
    state._pollErr = "";
    if (!period) return;

    // 首次只登记期号，不自动跑（避免一开粘贴板就狂跑）
    if (!state.watchPeriod) {
      state.watchPeriod = period;
      log("已监视开奖期号: " + period + "（命令不换时，下一期开奖会自动续跑）");
      saveState();
      return;
    }

    if (period === state.watchPeriod) return;

    const prev = state.watchPeriod;
    state.watchPeriod = period;
    log("新一期开奖: " + prev + " → " + period);
    saveState();

    // 命令还在且未换：接着跑
    if (state.command && !state.running) {
      await runCommand("新期开奖自动续跑 " + period);
    } else if (!state.command) {
      log("有新期，但当前停工，不跑");
    } else {
      log("有新期，但上轮还在执行，本轮跳过");
    }
  } catch (e) {
    if (!state._pollErr || state._pollErr !== String(e.message || e)) {
      state._pollErr = String(e.message || e);
      log("期号监视暂失败: " + state._pollErr);
    }
  } finally {
    setTimeout(pollLoop, POLL_MS);
  }
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let buf = "";
    req.setEncoding("utf8");
    req.on("data", (c) => (buf += c));
    req.on("end", () => resolve(buf));
    req.on("error", reject);
  });
}

function send(res, code, data, type) {
  const body = type === "html" ? data : JSON.stringify(data);
  res.writeHead(code, {
    "Content-Type": (type === "html" ? "text/html" : "application/json") + "; charset=utf-8",
    "Cache-Control": "no-store"
  });
  res.end(body);
}

function loadPersistedCommand() {
  try {
    if (fs.existsSync(CMD_FILE)) {
      const raw = fs.readFileSync(CMD_FILE, "utf8");
      setCommand(raw, false);
      return;
    }
  } catch (_e) {}
  setCommand("停", false);
}

const server = http.createServer(async (req, res) => {
  const u = new URL(req.url || "/", "http://127.0.0.1");
  try {
    if (req.method === "GET" && (u.pathname === "/" || u.pathname === "/index.html")) {
      send(res, 200, fs.readFileSync(HTML_FILE, "utf8"), "html");
      return;
    }
    if (req.method === "GET" && u.pathname === "/api/status") {
      send(res, 200, publicStatus());
      return;
    }
    if (req.method === "POST" && u.pathname === "/api/command") {
      const raw = await readBody(req);
      let body = {};
      try {
        body = JSON.parse(raw || "{}");
      } catch (_e) {
        body = {};
      }
      const out = setCommand(body.command, body.runNow !== false);
      send(res, out.ok ? 200 : 400, out);
      return;
    }
    send(res, 404, { ok: false, message: "not found" });
  } catch (e) {
    send(res, 500, { ok: false, message: e && e.message ? e.message : String(e) });
  }
});

server.on("error", (e) => {
  console.error("Server error:", e && e.message ? e.message : e);
  console.error("If port in use, close old paste-board window first.");
  try {
    if (process.platform === "win32") {
      // keep console visible when double-clicked
    }
  } catch (_e) {}
  setTimeout(() => process.exit(1), 5000);
});

server.listen(PORT, "127.0.0.1", () => {
  loadPersistedCommand();
  try {
    loadAttackFromDisk();
  } catch (_e) {}
  log("粘贴板已启动 http://127.0.0.1:" + PORT + "/");
  setTimeout(pollLoop, 3000);
  if (process.platform === "win32") {
    spawn("cmd.exe", ["/c", "start", "", "http://127.0.0.1:" + PORT + "/"], {
      windowsHide: true,
      detached: true,
      stdio: "ignore"
    }).unref();
  }
});
