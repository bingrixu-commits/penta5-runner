#!/usr/bin/env node
/**
 * 把已有回删号码转成投注格式：002x,004x,...各（分两批）
 * 读 回删结果.json 的 codes，或 回删结果.txt 里的三位数。
 */
"use strict";

const fs = require("fs");
const path = require("path");
const vm = require("vm");

const DIR = __dirname;
const BATCH1 = 300;
const OUT1 = path.join(DIR, "回删结果-第1批.txt");
const OUT2 = path.join(DIR, "回删结果-第2批.txt");
const OUT_ALL = path.join(DIR, "回删结果-投注格式.txt");

function loadApi() {
  const file = path.join(DIR, "txt_attack_convert.js");
  const code = fs.readFileSync(file, "utf8");
  const sb = { console, module: { exports: {} }, exports: {}, require };
  sb.global = sb;
  vm.runInNewContext(code, sb, { filename: file });
  const api = sb.global.Penta5AttackTxtConvert;
  if (!api || typeof api.formatThreeDingGeList !== "function") {
    throw new Error("转换库缺少 formatThreeDingGeList");
  }
  return api;
}

function loadCodes() {
  const jsonFile = path.join(DIR, "回删结果.json");
  if (fs.existsSync(jsonFile)) {
    const j = JSON.parse(fs.readFileSync(jsonFile, "utf8"));
    if (Array.isArray(j.codes) && j.codes.length) return { codes: j.codes.map(String), combo: j.comboName || "千百十" };
    if (j.result && Array.isArray(j.result.codes) && j.result.codes.length) {
      return { codes: j.result.codes.map(String), combo: j.comboName || "千百十" };
    }
  }
  const txtFile = path.join(DIR, "回删结果.txt");
  if (!fs.existsSync(txtFile)) throw new Error("找不到 回删结果.json / 回删结果.txt，请先跑一键回删");
  const raw = fs.readFileSync(txtFile, "utf8");
  const codes = [];
  const seen = {};
  const re = /\b(\d{3})\b/g;
  let m;
  while ((m = re.exec(raw))) {
    if (!seen[m[1]]) {
      seen[m[1]] = true;
      codes.push(m[1]);
    }
  }
  // 说明里的样例期号也会带 3 位数，优先取「现剩」附近大段：取出现次数排序后的主体
  if (codes.length < 50) throw new Error("回删结果.txt 里解析到的三位数太少，请用新版再跑一次回删");
  let combo = "千百十";
  if (/百十个/.test(raw)) combo = "百十个";
  else if (/千十个|万十个/.test(raw)) combo = "千十个";
  else if (/千百个/.test(raw)) combo = "千百个";
  return { codes, combo };
}

function main() {
  const api = loadApi();
  const { codes, combo } = loadCodes();
  const parts =
    typeof api.threeDingCopyParts === "function"
      ? api.threeDingCopyParts(codes, BATCH1, combo)
      : null;
  const list = (parts && parts.tokens) || codes.slice().sort();
  const text1 =
    (parts && parts.part1Text) || api.formatThreeDingGeList(list.slice(0, BATCH1), null, combo);
  const text2 =
    (parts && parts.part2Text) ||
    (list.length > BATCH1 ? api.formatThreeDingGeList(list.slice(BATCH1), null, combo) : "");
  const textAll = api.formatThreeDingGeList(list, null, combo);

  fs.writeFileSync(OUT1, text1 + "\n", "utf8");
  fs.writeFileSync(OUT2, (text2 || "") + (text2 ? "\n" : ""), "utf8");
  fs.writeFileSync(OUT_ALL, textAll + "\n", "utf8");
  fs.writeFileSync(path.join(DIR, "看这个-有逗号和各.txt"), text1 + "\n", "utf8");

  console.log("组合: " + combo + "  共 " + list.length + " 组");
  console.log("已写: " + OUT1);
  console.log("样例: " + text1.slice(0, 60) + "...");
  console.log("已写: " + OUT2);
  console.log("已写: " + OUT_ALL);
  console.log("已写: 看这个-有逗号和各.txt");
  console.log("格式应为: 002x,004x,...各");
}

main();
