﻿@echo off
cd /d "%~dp0"
title grab-three
echo ========================================
echo  Grab THREE-DING attack text
echo ========================================
echo.
where node >nul 2>nul
if errorlevel 1 (
  echo ERROR: Node.js not found
  pause
  goto :keep
)
node "%~dp0grab-three.js" --history 20 > "%~dp0last-run.log" 2>&1
type "%~dp0last-run.log"
if errorlevel 1 (
  echo ERROR: grab failed
  pause
  goto :keep
)
if exist "%~dp0attack-three-line.txt" (
  type "%~dp0attack-three-line.txt" | clip
  echo Copied: attack-three-line.txt
) else (
  echo WARN: run finished but attack-three-line.txt missing
)
echo.
pause
goto :eof

:keep
cmd /k
