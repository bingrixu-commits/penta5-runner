Set sh = CreateObject("WScript.Shell")
sh.CurrentDirectory = CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName)
sh.Run "cmd /c node desktop-server.js", 1, False
WScript.Sleep 800
sh.Run "http://127.0.0.1:3791/", 1, False
