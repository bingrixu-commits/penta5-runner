﻿@echo off
cd /d "%~dp0"
title grab-four
echo ========================================
echo  Grab FOUR-DING attack text
echo ========================================
echo.
where node >nul 2>nul
if errorlevel 1 (
  echo ERROR: Node.js not found. Install Node.js first.
  pause
  goto :keep
)
if not exist "%~dp0grab-four.js" (
  echo ERROR: grab-four.js missing
  dir /b "%~dp0*.js"
  pause
  goto :keep
)
echo Running...
node "%~dp0grab-four.js"
set ERR=%ERRORLEVEL%
if not "%ERR%"=="0" if not "%ERR%"=="3" if not "%ERR%"=="4" (
  echo ERROR: grab failed code %ERR%
  pause
  goto :keep
)
if exist "%~dp0attack-four-line.txt" (
  type "%~dp0attack-four-line.txt" | clip
  echo.
  echo OK copied. File: attack-four-line.txt
  echo Open attack-four-line.txt to view.
) else (
  echo WARN: attack-four-line.txt not created
)
echo.
pause
goto :eof

:keep
cmd /k
