﻿@echo off
chcp 65001 >nul
cd /d "%~dp0"
title huishan-today-498
echo 一键回删：阿里云200校验 → 今日命中删 → 不少于498
echo.
where node >nul 2>nul
if errorlevel 1 (
  echo [ERROR] 未找到 node
  pause
  exit /b 1
)
if not exist "%~dp0txt_attack_convert.js" (
  echo [ERROR] 缺少 txt_attack_convert.js
  pause
  exit /b 1
)
if not exist "%~dp0本机回删.js" (
  echo [ERROR] 缺少 本机回删.js
  pause
  exit /b 1
)
node "%~dp0本机回删.js" --out
if errorlevel 1 (
  echo [ERROR] 回删失败
  pause
  exit /b 1
)
echo.
pause
