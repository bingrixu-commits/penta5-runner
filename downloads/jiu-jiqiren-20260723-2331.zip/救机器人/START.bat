﻿@echo off
chcp 65001 >nul
cd /d "%~dp0"
title huishan-today-498
echo 一键回删：阿里云200校验 → 今日命中删 → 不少于498 → 分两批复制
echo.
where node >nul 2>nul
if errorlevel 1 (
  echo [ERROR] 未找到 node
  pause
  exit /b 1
)
node "%~dp0本机回删.js" --out
if errorlevel 1 (
  echo [ERROR] 回删失败
  pause
  exit /b 1
)
echo.
if exist "%~dp0回删结果-第1批.txt" (
  type "%~dp0回删结果-第1批.txt" | clip
  echo 第1批已复制到剪贴板
  echo 第2批文件: 回删结果-第2批.txt （第1批打完后打开全选复制再贴）
)
echo.
pause
