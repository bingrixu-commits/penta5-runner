#!/usr/bin/env node
/**
 * 粘贴板：粘贴命令调度抓/回删；空或「停」=停工；命令不变则新一期自动再跑。
 *
 *   node 粘贴板.js
 * 浏览器打开 http://127.0.0.1:3792/
 */
"use strict";

const fs = require("fs");
const path = require("path");
const http = require("http");
const { spawn } = require("child_process");
const { URL } = require("url");

const DIR = __dirname;
const PORT = Number(process.env.PASTE_PORT || 3792);
const HTML_FILE = fs.existsSync(path.join(DIR, "粘贴板.html"))
  ? path.join(DIR, "粘贴板.html")
  : path.join(DIR, "paste-board.html");
const CMD_FILE = path.join(DIR, "命令.txt");
const STATE_FILE = path.join(DIR, "粘贴板状态.json");
const PANEL_PASSWORD = process.env.PANEL_PASSWORD || "147258";
const PANEL_BASES = (
  process.env.PANEL_BASES ||
  "http://8.210.5.221:3001,http://127.0.0.1:3001"
)
  .split(",")
  .map((s) => s.trim())
  .filter(Boolean);
const POLL_MS = Number(process.env.PASTE_POLL_MS || 20000);
/** 抓码启动前等待，等面板落数，避免开奖瞬间卡住/空抓 */
const GRAB_START_DELAY_MS = Math.max(0, Number(process.env.PASTE_GRAB_DELAY_MS || 60 * 1000));
/** 单次子进程（抓码/回删）超时，超时强杀，防止卡住后永远「上轮还在跑」像罢工 */
const CHILD_TIMEOUT_MS = Math.max(
  60 * 1000,
  Number(process.env.PASTE_CHILD_TIMEOUT_MS || 10 * 60 * 1000)
);
/** 整轮命令最长占用（含抓码延时），超时强制解锁 running */
const RUN_MAX_MS = Math.max(
  CHILD_TIMEOUT_MS + GRAB_START_DELAY_MS + 30 * 1000,
  Number(process.env.PASTE_RUN_MAX_MS || 15 * 60 * 1000)
);

const state = {
  command: "", // grab | grab4 | huishan | both | ""
  commandRaw: "",
  commandDisplay: "（停工）",
  running: false,
  runStartedAt: 0,
  pendingRerun: false,
  pendingRerunReason: "",
  activeChild: null,
  watchPeriod: "",
  lastPeriodRun: "",
  lastSummary: "",
  lastError: "",
  lastAttackText: "",
  lastAttackKind: "",
  lastAttackAt: "",
  lastAttackPeriod: "",
  lastCodesText: "",
  lastCodesMeta: "",
  lastOk: null,
  /** 待开奖核验：上一轮三定出码 */
  pendingHit: null,
  /** 最近一次核验：{ period, openCode, hit, text, at, kind } */
  lastHit: null,
  /** 分类型待核验 / 结果：三定出码、四定攻击语 */
  pendingByKind: { 三定: null, 四定: null },
  lastByKind: { 三定: null, 四定: null },
  logs: [],
  startedAt: new Date().toISOString()
};

function log(msg) {
  const line = "[" + new Date().toLocaleTimeString("zh-CN", { hour12: false }) + "] " + msg;
  state.logs.push(line);
  if (state.logs.length > 80) state.logs = state.logs.slice(-80);
  console.log(line);
  saveState();
}

function saveState() {
  try {
    fs.writeFileSync(
      STATE_FILE,
      JSON.stringify(
        {
          command: state.command,
          commandRaw: state.commandRaw,
          watchPeriod: state.watchPeriod,
          lastPeriodRun: state.lastPeriodRun,
          lastSummary: state.lastSummary,
          pendingHit: state.pendingHit,
          lastHit: state.lastHit,
          pendingByKind: state.pendingByKind,
          lastByKind: state.lastByKind,
          updatedAt: new Date().toISOString()
        },
        null,
        2
      ),
      "utf8"
    );
  } catch (_e) {}
}

function loadHitState() {
  try {
    if (fs.existsSync(STATE_FILE)) {
      const j = JSON.parse(fs.readFileSync(STATE_FILE, "utf8"));
      if (j && j.pendingHit) state.pendingHit = j.pendingHit;
      if (j && j.lastHit) state.lastHit = j.lastHit;
      if (j && j.pendingByKind && typeof j.pendingByKind === "object") {
        state.pendingByKind = Object.assign({ 三定: null, 四定: null }, j.pendingByKind);
      }
      if (j && j.lastByKind && typeof j.lastByKind === "object") {
        state.lastByKind = Object.assign({ 三定: null, 四定: null }, j.lastByKind);
      }
      // 兼容旧单槽
      if (state.pendingHit && state.pendingHit.kind && !state.pendingByKind[state.pendingHit.kind]) {
        state.pendingByKind[state.pendingHit.kind] = state.pendingHit;
      }
      if (state.lastHit && state.lastHit.kind && !state.lastByKind[state.lastHit.kind]) {
        state.lastByKind[state.lastHit.kind] = state.lastHit;
      }
    }
  } catch (_e) {}
  // 若无待核验，尝试从上次回删结果恢复三定
  if (!state.pendingByKind["三定"]) {
    try {
      const jfile = path.join(DIR, "回删结果.json");
      if (fs.existsSync(jfile)) {
        const j2 = JSON.parse(fs.readFileSync(jfile, "utf8"));
        if (j2 && j2.ok !== false) {
          const codes = Array.isArray(j2.codes)
            ? j2.codes.map(String)
            : j2.result && Array.isArray(j2.result.tokens)
              ? j2.result.tokens.map(String)
              : [];
          const target = readPredictPeriod();
          if (target && codes.length) {
            setPendingHit({
              kind: "三定",
              mode: "codes",
              targetPeriod: target,
              basePeriod: String(j2.latestPeriod || ""),
              comboName: j2.comboName || "千百十",
              codes: codes,
              attack: j2.attack || "",
              at: new Date().toLocaleString("zh-CN", { hour12: false })
            });
          }
        }
      }
    } catch (_e2) {}
  }
  // 恢复四定待核验
  if (!state.pendingByKind["四定"]) {
    try {
      const line =
        readLineFile(path.join(DIR, "攻击语一行-四定.txt")) ||
        readLineFile(path.join(DIR, "attack-four-line.txt"));
      const detailFile = path.join(DIR, "当期攻击语-四定.txt");
      let base = "";
      if (fs.existsSync(detailFile)) {
        const m = fs.readFileSync(detailFile, "utf8").match(/基准期:\s*(\d+)/);
        if (m) base = m[1];
      }
      let target = "";
      if (base && /^\d+$/.test(base)) {
        try {
          target = String(BigInt(base) + 1n);
        } catch (_e3) {}
      }
      if (line && /四定/.test(line) && target) {
        setPendingHit({
          kind: "四定",
          mode: "attack",
          targetPeriod: target,
          basePeriod: base,
          attack: line,
          at: new Date().toLocaleString("zh-CN", { hour12: false })
        });
      }
    } catch (_e4) {}
  }
}

const COMBO_INDEXES = {
  千百十: [0, 1, 2],
  百十个: [1, 2, 3],
  千百个: [0, 1, 3],
  千十个: [0, 2, 3],
  万十个: [0, 2, 3]
};

function readPredictPeriod() {
  const detailFile = path.join(DIR, "当期攻击语.txt");
  try {
    if (!fs.existsSync(detailFile)) return "";
    const raw = fs.readFileSync(detailFile, "utf8");
    const m = raw.match(/预测期[:：\s]*(\d{8,})/);
    if (m) return m[1];
    const m2 = raw.match(/基准期[:：\s]*(\d{8,})\s*→\s*预测期[:：\s]*(\d{8,})/);
    if (m2) return m2[2];
  } catch (_e) {}
  return "";
}

function openDigitsFromRecord(rec) {
  if (!rec) return "";
  if (Array.isArray(rec.numbers) && rec.numbers.length >= 4) {
    return rec.numbers.slice(0, 4).map((n) => String(n).replace(/\D/g, "").slice(-1)).join("");
  }
  const code = String(rec.openCode || rec.code || rec.number || "").replace(/\D/g, "");
  if (code.length >= 4) return code.slice(0, 4);
  return "";
}

function trioCodeFromOpen4(open4, comboName) {
  const idxs = COMBO_INDEXES[String(comboName || "千百十")] || COMBO_INDEXES["千百十"];
  const s = String(open4 || "");
  if (!/^\d{4}$/.test(s)) return "";
  return idxs.map((i) => s.charAt(i)).join("");
}

function parseCodesSet(textOrList) {
  const set = Object.create(null);
  if (Array.isArray(textOrList)) {
    textOrList.forEach((t) => {
      const d = String(t || "").replace(/\D/g, "");
      if (/^\d{3}$/.test(d)) set[d] = true;
    });
    return set;
  }
  String(textOrList || "")
    .replace(/各/g, ",")
    .split(/[,\s]+/)
    .forEach((tok) => {
      const d = String(tok || "").replace(/[xX+]/g, "").replace(/\D/g, "");
      if (/^\d{3}$/.test(d)) set[d] = true;
    });
  return set;
}

function setPendingHit(payload) {
  if (!payload) {
    state.pendingHit = null;
    saveState();
    return;
  }
  const kind = payload.kind || (payload.mode === "attack" ? "四定" : "三定");
  payload.kind = kind;
  if (!state.pendingByKind || typeof state.pendingByKind !== "object") {
    state.pendingByKind = { 三定: null, 四定: null };
  }
  state.pendingByKind[kind] = payload;
  state.pendingHit = payload; // 兼容旧字段：最近一次登记
  saveState();
}

function setLastHit(payload) {
  if (!payload) {
    state.lastHit = null;
    saveState();
    return;
  }
  const kind = payload.kind || "三定";
  payload.kind = kind;
  if (!state.lastByKind || typeof state.lastByKind !== "object") {
    state.lastByKind = { 三定: null, 四定: null };
  }
  state.lastByKind[kind] = payload;
  state.lastHit = payload;
  saveState();
}

function heweiOfDigits(digits) {
  let sum = 0;
  String(digits || "")
    .split("")
    .forEach((d) => {
      sum += Number(d || 0);
    });
  return String(sum % 10);
}

function codeContainsPair(code, pair) {
  const c = String(code || "");
  return String(pair || "")
    .split("")
    .every((d) => c.indexOf(d) >= 0);
}

/** 四定攻击语是否罩住开奖四码（定位池+除对数+三数合尾保留池+千百十个合） */
function fourDingAttackHits(open4, attack) {
  const raw = String(attack || "").replace(/\s+/g, "");
  const open = String(open4 || "").replace(/\D/g, "").slice(0, 4);
  if (!/^\d{4}$/.test(open) || !/四定/.test(raw)) return false;
  const a = open.charAt(0);
  const b = open.charAt(1);
  const c = open.charAt(2);
  const d = open.charAt(3);
  const pm = raw.match(/千(\d+)百(\d+)十(\d+)个(\d+)/);
  if (!pm) return false;
  if (pm[1].indexOf(a) < 0) return false;
  if (pm[2].indexOf(b) < 0) return false;
  if (pm[3].indexOf(c) < 0) return false;
  if (pm[4].indexOf(d) < 0) return false;
  const pairM = raw.match(/除对数(\d{2})/);
  if (pairM && codeContainsPair(open, pairM[1])) return false;
  const trioHewei = [
    { lab: "千百十合", idxs: [0, 1, 2] },
    { lab: "百十个合", idxs: [1, 2, 3] },
    { lab: "千百个合", idxs: [0, 1, 3] },
    { lab: "千十个合", idxs: [0, 2, 3] },
    { lab: "万十个合", idxs: [0, 2, 3] }
  ];
  for (let i = 0; i < trioHewei.length; i++) {
    const t = trioHewei[i];
    const re = new RegExp(t.lab + "(\\d+)");
    const m = raw.match(re);
    if (!m) continue;
    const keep = m[1];
    const hw = heweiOfDigits(t.idxs.map((ix) => open.charAt(ix)).join(""));
    if (keep.indexOf(hw) < 0) return false;
  }
  const fourM = raw.match(/千百十个合(\d+)/);
  if (fourM) {
    const hw4 = heweiOfDigits(open);
    if (fourM[1].indexOf(hw4) < 0) return false;
  }
  return true;
}

function nextPeriodId(period) {
  const p = String(period || "");
  if (!/^\d+$/.test(p)) return "";
  try {
    return String(BigInt(p) + 1n);
  } catch (_e) {
    return "";
  }
}

/** 开奖后核验：三定看出码；四定看攻击语是否罩住开奖号 */
async function tryJudgePendingHit(openedPeriod) {
  const opened = String(openedPeriod || "");
  if (!opened) return;
  const got = await fetchOpen4ForPeriod(opened);
  if (!got || !got.open4) {
    const hasPending =
      (state.pendingByKind &&
        ((state.pendingByKind["三定"] &&
          String(state.pendingByKind["三定"].targetPeriod) === opened) ||
          (state.pendingByKind["四定"] &&
            String(state.pendingByKind["四定"].targetPeriod) === opened))) ||
      (state.pendingHit && String(state.pendingHit.targetPeriod) === opened);
    if (hasPending) log("核验：期" + opened + " 尚未取到开奖号，稍后重试");
    return;
  }
  const kinds = ["三定", "四定"];
  for (let ki = 0; ki < kinds.length; ki++) {
    const kind = kinds[ki];
    const pending =
      (state.pendingByKind && state.pendingByKind[kind]) ||
      (state.pendingHit && state.pendingHit.kind === kind ? state.pendingHit : null) ||
      (state.pendingHit && !state.pendingHit.kind && kind === "三定" ? state.pendingHit : null);
    if (!pending || String(pending.targetPeriod) !== opened) continue;
    if (
      state.lastByKind &&
      state.lastByKind[kind] &&
      String(state.lastByKind[kind].period) === opened &&
      state.lastByKind[kind].hit != null
    ) {
      continue;
    }
    const at = new Date().toLocaleString("zh-CN", { hour12: false });
    let hit = false;
    let openCode = got.open4;
    let extra = {};
    if (kind === "四定" || pending.mode === "attack") {
      hit = fourDingAttackHits(got.open4, pending.attack || "");
      extra = { mode: "attack" };
    } else {
      const trio = trioCodeFromOpen4(got.open4, pending.comboName || "千百十");
      if (!/^\d{3}$/.test(trio)) {
        log("三定核验：开奖号无法映射 " + got.open4);
        continue;
      }
      openCode = trio;
      const set = parseCodesSet(pending.codes || pending.codesText || "");
      hit = !!set[trio];
      extra = { comboName: pending.comboName || "千百十", count: Object.keys(set).length, mode: "codes" };
    }
    const text = hit ? "中" : "不中";
    setLastHit(
      Object.assign(
        {
          kind: kind,
          period: opened,
          open4: got.open4,
          openCode: openCode,
          hit: hit,
          text: text,
          at: at,
          source: got.source || ""
        },
        extra
      )
    );
    log(
      kind +
        "核验：期" +
        opened +
        " 开奖" +
        got.open4 +
        (kind === "三定" ? "→" + openCode : "") +
        "　【" +
        text +
        "】"
    );
    if (state.pendingByKind) state.pendingByKind[kind] = null;
    if (state.pendingHit && String(state.pendingHit.targetPeriod) === opened) {
      state.pendingHit = null;
    }
    saveState();
  }
}

async function fetchOpen4ForPeriod(period) {
  const want = String(period || "");
  if (!want) return null;
  // 1) 本机开奖历史
  try {
    const histFile = path.join(DIR, "开奖历史.json");
    if (fs.existsSync(histFile)) {
      const raw = JSON.parse(fs.readFileSync(histFile, "utf8"));
      const rows = Array.isArray(raw.history) ? raw.history : [];
      for (let i = 0; i < rows.length; i++) {
        const row = rows[i] || {};
        const p = String(row.period || row.issue || row.uid || "");
        if (p === want) {
          const open4 = openDigitsFromRecord(row);
          if (open4) return { open4, source: "local-history" };
        }
      }
    }
  } catch (_e) {}
  // 2) 面板 latest / history
  for (const base of PANEL_BASES) {
    try {
      const root = String(base || "").replace(/\/$/, "");
      const login = await httpJson(root + "/login", {
        method: "POST",
        body: { password: PANEL_PASSWORD },
        timeout: 15000
      });
      const cookie = cookieFromSetCookie(login.headers && login.headers["set-cookie"]);
      const st = await httpJson(root + "/state", {
        timeout: 60000,
        headers: cookie ? { Cookie: cookie } : {}
      });
      const data = st.data || {};
      const latestRec = data.latestRecord || data.latest || {};
      const latestPeriod = String(
        data.sharedHistoryLatestPeriod ||
          data.sharedHistoryRdsLatestPeriod ||
          latestRec.period ||
          latestRec.uid ||
          ""
      );
      if (latestPeriod === want) {
        const open4 = openDigitsFromRecord(latestRec);
        if (open4) return { open4, source: root + "/state" };
      }
      const hist = Array.isArray(data.history) ? data.history : [];
      for (let i = 0; i < hist.length; i++) {
        const row = hist[i] || {};
        const p = String(row.period || row.issue || row.uid || "");
        if (p === want) {
          const open4 = openDigitsFromRecord(row);
          if (open4) return { open4, source: root + "/state.history" };
        }
      }
    } catch (_e) {}
  }
  return null;
}

function normalizeCommand(raw) {
  let s = String(raw == null ? "" : raw)
    .replace(/^\uFEFF/, "")
    .trim()
    .replace(/\s+/g, "");
  if (!s || s === "停" || s === "停止" || s === "stop" || s === "idle") {
    return { key: "", raw: s || "", display: "（停工）" };
  }
  if (
    s === "抓" ||
    s === "运行" ||
    s === "抓码" ||
    s === "攻击语" ||
    /^抓攻击/.test(s)
  ) {
    return { key: "grab", raw: s, display: "抓（三定攻击语）" };
  }
  if (s === "抓四定" || s === "四定" || s === "运行四定") {
    return { key: "grab4", raw: s, display: "抓（四定攻击语）" };
  }
  if (s === "回删" || s === "一键回删" || s === "huishan") {
    return { key: "huishan", raw: s, display: "回删" };
  }
  if (
    s === "抓+回删" ||
    s === "抓回删" ||
    s === "全自动" ||
    s === "抓＋回删"
  ) {
    return { key: "both", raw: s, display: "抓+回删" };
  }
  return { key: null, raw: s, display: "未知命令" };
}

function killActiveChild(reason) {
  const child = state.activeChild;
  if (!child || child.killed) return;
  try {
    log("强杀子进程: " + (reason || "超时"));
    child.kill("SIGTERM");
  } catch (_e) {}
  setTimeout(() => {
    try {
      if (state.activeChild === child && !child.killed) child.kill("SIGKILL");
    } catch (_e2) {}
  }, 2000);
}

function runNode(script, args) {
  return new Promise((resolve, reject) => {
    const child = spawn(process.execPath, [path.join(DIR, script)].concat(args || []), {
      cwd: DIR,
      windowsHide: true,
      env: process.env
    });
    state.activeChild = child;
    let out = "";
    let err = "";
    let settled = false;
    const timer = setTimeout(() => {
      if (settled) return;
      killActiveChild(script + " 超时 " + Math.round(CHILD_TIMEOUT_MS / 1000) + "s");
      settled = true;
      state.activeChild = null;
      reject(
        new Error(
          script +
            " 超时（" +
            Math.round(CHILD_TIMEOUT_MS / 1000) +
            "s）已强杀，避免卡死罢工" +
            (err || out ? "\n" + (err || out).slice(-300) : "")
        )
      );
    }, CHILD_TIMEOUT_MS);
    child.stdout.on("data", (d) => {
      out += d.toString("utf8");
    });
    child.stderr.on("data", (d) => {
      err += d.toString("utf8");
    });
    child.on("error", (e) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      if (state.activeChild === child) state.activeChild = null;
      reject(e);
    });
    child.on("close", (code) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      if (state.activeChild === child) state.activeChild = null;
      if (code === 0) resolve({ out, err });
      else
        reject(
          new Error(
            script +
              " 退出码 " +
              code +
              (err || out ? "\n" + (err || out).slice(-500) : "")
          )
        );
    });
  });
}

function clipFile(file) {
  return new Promise((resolve) => {
    if (process.platform !== "win32" || !fs.existsSync(file)) {
      resolve(false);
      return;
    }
    const child = spawn(
      process.env.ComSpec || "cmd.exe",
      ["/c", "type", file, "|", "clip"],
      { cwd: DIR, windowsHide: true, shell: true }
    );
    child.on("close", () => resolve(true));
    child.on("error", () => resolve(false));
  });
}

function readLineFile(file) {
  if (!fs.existsSync(file)) return "";
  const lines = fs
    .readFileSync(file, "utf8")
    .trim()
    .split(/\r?\n/)
    .map((s) => s.trim())
    .filter(Boolean);
  return lines.length ? lines[lines.length - 1] : "";
}

function setAttackResult(kind, text, period) {
  state.lastAttackKind = kind || "";
  state.lastAttackText = String(text || "").trim();
  state.lastAttackAt = new Date().toLocaleString("zh-CN", { hour12: false });
  if (period != null && String(period).trim()) state.lastAttackPeriod = String(period).trim();
  saveState();
}

function setCodesResult(text, meta, ok) {
  state.lastCodesText = String(text || "").trim();
  state.lastCodesMeta = String(meta || "").trim();
  if (ok === true || ok === false) state.lastOk = ok;
  saveState();
}

function loadAttackFromDisk() {
  const fourEn = path.join(DIR, "attack-four-line.txt");
  const fourZh = path.join(DIR, "攻击语一行-四定.txt");
  const threeEn = path.join(DIR, "attack-three-line.txt");
  const threeZh = path.join(DIR, "攻击语一行.txt");
  const four = readLineFile(fourEn) || readLineFile(fourZh);
  const three = readLineFile(threeEn) || readLineFile(threeZh);
  let fourM = 0;
  let threeM = 0;
  try {
    if (fs.existsSync(fourEn)) fourM = fs.statSync(fourEn).mtimeMs;
    else if (fs.existsSync(fourZh)) fourM = fs.statSync(fourZh).mtimeMs;
    if (fs.existsSync(threeEn)) threeM = fs.statSync(threeEn).mtimeMs;
    else if (fs.existsSync(threeZh)) threeM = fs.statSync(threeZh).mtimeMs;
  } catch (_e) {}

  // 按当前命令显示对应攻击语，避免「抓+回删」执行中仍刷出旧四定
  const cmd = String(state.command || "");
  if (cmd === "grab4") {
    if (four) setAttackResult("四定", four);
    else if (three) setAttackResult("三定", three);
  } else if (cmd === "grab" || cmd === "both" || cmd === "huishan") {
    if (three) setAttackResult("三定", three);
    else if (four) setAttackResult("四定", four);
  } else if (four && (!three || fourM >= threeM)) {
    setAttackResult("四定", four);
  } else if (three) {
    setAttackResult("三定", three);
  }

  // 重启后尽量把上次三定出码也刷回网页
  if (!state.lastCodesText) {
    try {
      const jfile = path.join(DIR, "回删结果.json");
      const b1 = path.join(DIR, "回删结果-第1批.txt");
      const b2 = path.join(DIR, "回删结果-第2批.txt");
      if (fs.existsSync(jfile) || fs.existsSync(b1)) {
        let text1 = fs.existsSync(b1) ? fs.readFileSync(b1, "utf8").trim() : "";
        let text2 = fs.existsSync(b2) ? fs.readFileSync(b2, "utf8").trim() : "";
        let meta = "磁盘恢复的上次出码";
        let ok = null;
        if (fs.existsSync(jfile)) {
          const j = JSON.parse(fs.readFileSync(jfile, "utf8"));
          if (j && j.ok === false) ok = false;
          else if (j && j.ok === true) ok = true;
          if (j && j.attack) setAttackResult("三定", j.attack, j.latestPeriod || "");
          if (j && j.result) {
            meta =
              (ok === false ? "失败" : "成功") +
              "　期" +
              (j.latestPeriod || "?") +
              "　排除后 " +
              (j.result.afterFilter != null ? j.result.afterFilter : "--") +
              " → 删 " +
              (j.result.deletedUnique != null ? j.result.deletedUnique : "--") +
              " → 剩 " +
              (j.result.count != null ? j.result.count : "--") +
              (j.result.stoppedAtFloor ? "（触底线498）" : "");
          }
          if (!text1 && j && j.batch1Text) text1 = String(j.batch1Text).trim();
          if (!text2 && j && j.batch2Text) text2 = String(j.batch2Text).trim();
        }
        const board =
          (text1 ? "—— 第1批（已复制剪贴板）——\n" + text1 + "\n" : "") +
          (text2 ? "\n—— 第2批 ——\n" + text2 + "\n" : "");
        if (board.trim()) setCodesResult(board.trim(), meta, ok);
      }
    } catch (_e) {}
  }
}

async function doGrab() {
  log("执行：抓三定攻击语");
  const prev = state.lastAttackText || "";
  const script = fs.existsSync(path.join(DIR, "抓四项转攻击语.js"))
    ? "抓四项转攻击语.js"
    : "grab-three.js";
  await runNode(script, ["--history", "20"]);
  const lineFile = path.join(DIR, "攻击语一行.txt");
  const lineFileEn = path.join(DIR, "attack-three-line.txt");
  const detailFile = path.join(DIR, "当期攻击语.txt");
  const line = readLineFile(lineFile);
  if (line) {
    fs.writeFileSync(lineFile, line + "\n", "utf8");
    fs.writeFileSync(lineFileEn, line + "\n", "utf8");
  }
  let period = "";
  try {
    if (fs.existsSync(detailFile)) {
      const m = fs.readFileSync(detailFile, "utf8").match(/(?:基准期|目标期|期号)[:：\s]*(\d{8,})/);
      if (m) period = m[1];
    }
  } catch (_e) {}
  if (!period) period = String(state.watchPeriod || "");
  await clipFile(lineFile);
  setAttackResult("三定", line, period);
  if (!line) {
    state.lastSummary = "三定抓取完成，但未读到攻击语";
    state.lastOk = false;
  } else if (line === prev) {
    state.lastSummary =
      "三定已重抓期" + (period || "?") + "；正文碰巧与上期相同（看更新时间）";
    state.lastOk = true;
    log("当前行: " + line);
  } else {
    state.lastSummary = "三定攻击语已更新 期" + (period || "?");
    state.lastOk = true;
    log("新攻击语: " + line);
  }
  log(state.lastSummary);
}

async function doGrabFour() {
  log("执行：抓四定转攻击语");
  const prev = state.lastAttackText || "";
  const script = fs.existsSync(path.join(DIR, "抓四定转攻击语.js"))
    ? "抓四定转攻击语.js"
    : "grab-four.js";
  await runNode(script, []);
  const lineFile = path.join(DIR, "attack-four-line.txt");
  const lineFileZh = path.join(DIR, "攻击语一行-四定.txt");
  const detailFile = path.join(DIR, "当期攻击语-四定.txt");
  const latestFile = path.join(DIR, "最新四定结果.txt");
  const line = readLineFile(lineFile) || readLineFile(lineFileZh);
  let period = "";
  try {
    if (fs.existsSync(detailFile)) {
      const m = fs.readFileSync(detailFile, "utf8").match(/基准期:\s*(\d+)/);
      if (m) period = m[1];
    }
  } catch (_e) {}
  if (!period) period = String(state.watchPeriod || "");
  const now = new Date().toLocaleString("zh-CN", { hour12: false });
  // 强制重写一行文件，避免 Windows 看不出“已更新”
  if (line) {
    fs.writeFileSync(lineFileZh, line + "\n", "utf8");
    fs.writeFileSync(lineFile, line + "\n", "utf8");
    fs.writeFileSync(
      latestFile,
      [
        "期号: " + (period || "--"),
        "更新: " + now,
        "类型: 四定",
        "",
        line,
        ""
      ].join("\n"),
      "utf8"
    );
  }
  await clipFile(lineFileZh);
  setAttackResult("四定", line, period);
  if (line) {
    const target = nextPeriodId(period);
    if (target) {
      setPendingHit({
        kind: "四定",
        mode: "attack",
        targetPeriod: target,
        basePeriod: String(period || ""),
        attack: line,
        at: now
      });
      log("已登记四定核验：待期" + target + " 开奖后对照攻击语 → 显示中/不中");
    }
  }
  if (!line) {
    state.lastSummary = "四定抓取完成，但未读到攻击语文件";
  } else if (line === prev) {
    state.lastSummary =
      "已重抓期" +
      (period || "?") +
      "；正文碰巧与上期相同（面板码未变）——请看「更新时间/期号」或打开 最新四定结果.txt";
    log(state.lastSummary);
    log("当前行: " + line);
  } else {
    state.lastSummary = "四定已更新 期" + (period || "?") + "（下方+最新四定结果.txt）";
    log(state.lastSummary);
    log("新攻击语: " + line);
  }
}

async function doHuishan() {
  log("执行：本机回删（三定出码）");
  await runNode("本机回删.js", ["--out"]);
  const b1 = path.join(DIR, "回删结果-第1批.txt");
  const b2 = path.join(DIR, "回删结果-第2批.txt");
  const jfile = path.join(DIR, "回删结果.json");
  const latestFile = path.join(DIR, "最新三定结果.txt");
  await clipFile(b1);

  let n1 = 0;
  let n2 = 0;
  let text1 = "";
  let text2 = "";
  let afterFilter = "--";
  let deleted = "--";
  let left = "--";
  let stopped = false;
  let attack = state.lastAttackText || "";
  let period = state.lastAttackPeriod || state.watchPeriod || "";
  let ok = true;
  let errMsg = "";

  try {
    if (fs.existsSync(b1)) {
      text1 = fs.readFileSync(b1, "utf8").trim();
      const t = text1.replace(/各\s*$/, "").trim();
      n1 = t ? t.split(/[,\s]+/).filter(Boolean).length : 0;
    }
    if (fs.existsSync(b2)) {
      text2 = fs.readFileSync(b2, "utf8").trim();
      const t2 = text2.replace(/各\s*$/, "").trim();
      n2 = t2 ? t2.split(/[,\s]+/).filter(Boolean).length : 0;
    }
    if (fs.existsSync(jfile)) {
      const j = JSON.parse(fs.readFileSync(jfile, "utf8"));
      if (j && j.ok === false) {
        ok = false;
        errMsg = j.message || j.error || "回删失败";
      }
      if (j && j.attack) attack = j.attack;
      if (j && j.latestPeriod) period = j.latestPeriod;
      if (j && j.result) {
        afterFilter = j.result.afterFilter != null ? j.result.afterFilter : afterFilter;
        deleted = j.result.deletedUnique != null ? j.result.deletedUnique : deleted;
        left = j.result.count != null ? j.result.count : left;
        stopped = !!j.result.stoppedAtFloor;
      }
      if (j && Array.isArray(j.codes) && j.codes.length && !n1) {
        left = j.codes.length;
      }
    }
  } catch (e) {
    ok = false;
    errMsg = e && e.message ? e.message : String(e);
  }

  if (!text1 && !text2) {
    ok = false;
    if (!errMsg) errMsg = "没有回删结果文件";
  }

  const now = new Date().toLocaleString("zh-CN", { hour12: false });
  const meta =
    (ok ? "成功" : "失败") +
    "　期" +
    (period || "?") +
    "　排除后 " +
    afterFilter +
    " → 删 " +
    deleted +
    " → 剩 " +
    left +
    (stopped ? "（触底线498）" : "") +
    "　第1批 " +
    n1 +
    (n2 ? "　第2批 " + n2 : "") +
    "　更新 " +
    now +
    (errMsg ? "　" + errMsg : "");

  const boardCodes =
    (text1 ? "—— 第1批（已复制剪贴板）——\n" + text1 + "\n" : "") +
    (text2 ? "\n—— 第2批 ——\n" + text2 + "\n" : "");

  setCodesResult(boardCodes.trim(), meta, ok);
  if (attack) setAttackResult("三定", attack, period);

  // 登记待开奖核验：对照预测期开奖，看开奖三位是否落在出码里
  if (ok) {
    let codes = [];
    let comboName = "千百十";
    try {
      if (fs.existsSync(jfile)) {
        const j2 = JSON.parse(fs.readFileSync(jfile, "utf8"));
        if (j2 && Array.isArray(j2.codes)) codes = j2.codes.map(String);
        else if (j2 && j2.result && Array.isArray(j2.result.tokens)) {
          codes = j2.result.tokens.map(String);
        }
        if (j2 && (j2.comboName || (j2.result && j2.result.comboName))) {
          comboName = j2.comboName || j2.result.comboName;
        }
      }
    } catch (_e) {}
    if (!codes.length) {
      const set = parseCodesSet((text1 || "") + "," + (text2 || ""));
      codes = Object.keys(set);
    }
    const targetPeriod = readPredictPeriod() || "";
    // 没有预测期时：用监视期+1 兜底（常见连号期）
    let target = targetPeriod;
    if (!target && period && /^\d+$/.test(String(period))) {
      try {
        target = String(BigInt(period) + 1n);
      } catch (_e2) {
        target = "";
      }
    }
    if (target && codes.length) {
      setPendingHit({
        kind: "三定",
        mode: "codes",
        targetPeriod: target,
        basePeriod: String(period || ""),
        comboName: comboName,
        codes: codes,
        attack: attack || "",
        at: now
      });
      log(
        "已登记出码核验：待期" +
          target +
          " 开奖后对照 " +
          codes.length +
          " 组（" +
          comboName +
          "）→ 显示中/不中"
      );
    }
  }

  fs.writeFileSync(
    latestFile,
    [
      "状态: " + (ok ? "成功" : "失败"),
      "期号: " + (period || "--"),
      "更新: " + now,
      "攻击语: " + (attack || "--"),
      "排除后: " + afterFilter + "  今日已删: " + deleted + "  现剩: " + left + (stopped ? "（触底线498）" : ""),
      "第1批: " + n1 + "  第2批: " + n2,
      errMsg ? "错误: " + errMsg : "",
      "",
      "【攻击语】",
      attack || "",
      "",
      "【出码】",
      boardCodes.trim(),
      ""
    ]
      .filter((x, i, a) => x !== "" || (i > 0 && a[i - 1] !== ""))
      .join("\n"),
    "utf8"
  );

  state.lastSummary = ok
    ? "三定抓取回删完成：剩" + left + "　网页下方已出码"
    : "三定回删失败：" + (errMsg || "见日志");
  state.lastOk = ok;
  log(state.lastSummary);
  log(meta);
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, Math.max(0, Number(ms) || 0)));
}

async function runCommand(reason) {
  if (!state.command) {
    log("停工中，跳过（" + reason + "）");
    return;
  }
  if (state.running) {
    // 卡住过久：强制解锁，避免「工作一阵就罢工」
    const lived = Date.now() - (state.runStartedAt || 0);
    if (state.runStartedAt && lived > RUN_MAX_MS) {
      log(
        "本轮已跑 " +
          Math.round(lived / 1000) +
          "s 超时，强制解锁并强杀子进程（防罢工）"
      );
      killActiveChild("整轮超时");
      state.running = false;
      state.activeChild = null;
    } else {
      state.pendingRerun = true;
      state.pendingRerunReason = reason || "新期补跑";
      log("上一次还在跑，本轮登记补跑（" + reason + "）");
      return;
    }
  }
  state.running = true;
  state.runStartedAt = Date.now();
  state.lastError = "";
  saveState();
  const beat = setInterval(() => {
    if (!state.running) return;
    const sec = Math.round((Date.now() - state.runStartedAt) / 1000);
    log("仍在干活中…已 " + sec + "s（未罢工，请勿关黑窗）");
  }, 60 * 1000);
  try {
    log("开始执行「" + state.commandDisplay + "」· " + reason);
    const needGrab =
      state.command === "grab" || state.command === "grab4" || state.command === "both";
    if (needGrab && GRAB_START_DELAY_MS > 0) {
      log(
        "抓码延后 " +
          Math.round(GRAB_START_DELAY_MS / 1000) +
          " 秒启动（等面板落数，避免卡住）"
      );
      await sleep(GRAB_START_DELAY_MS);
      if (!state.command) {
        log("延时期间已停工，取消抓码");
        return;
      }
    }
    if (state.command === "grab" || state.command === "both") await doGrab();
    if (state.command === "grab4") await doGrabFour();
    if (state.command === "huishan" || state.command === "both") await doHuishan();
    if (state.watchPeriod) state.lastPeriodRun = state.watchPeriod;
    log("本轮结束");
  } catch (e) {
    state.lastError = e && e.message ? e.message : String(e);
    state.lastSummary = "失败: " + state.lastError.split("\n")[0];
    log(state.lastSummary);
    // 失败不改命令，继续待命下一期，绝不自动停工
  } finally {
    clearInterval(beat);
    state.running = false;
    state.runStartedAt = 0;
    state.activeChild = null;
    saveState();
    if (state.pendingRerun && state.command) {
      const why = state.pendingRerunReason || "补跑跳过的新期";
      state.pendingRerun = false;
      state.pendingRerunReason = "";
      setImmediate(() => runCommand(why));
    }
  }
}

function setCommand(raw, runNow) {
  const n = normalizeCommand(raw);
  if (n.key === null) {
      return { ok: false, message: "未知命令：「" + n.raw + "」。请用：抓 / 抓四定 / 回删 / 抓+回删 / 停" };
  }
  const prev = state.command;
  state.command = n.key;
  state.commandRaw = n.raw;
  state.commandDisplay = n.display;
  try {
    fs.writeFileSync(CMD_FILE, (n.raw || "停") + "\n", "utf8");
  } catch (_e) {}
  saveState();
  if (!n.key) {
    log("已停工");
    return { ok: true, ...publicStatus() };
  }
  log("命令生效: " + n.display + (prev === n.key ? "（未更换）" : "（已更换）"));
  // 立刻按新命令切换展示的攻击语，避免三定命令下仍显示旧四定
  try {
    loadAttackFromDisk();
  } catch (_e) {}
  if (runNow) {
    setImmediate(() => runCommand("手动生效"));
  }
  return { ok: true, ...publicStatus() };
}

function publicStatus() {
  // 每次状态查询也刷新磁盘上的最新攻击语，避免漏显示
  try {
    loadAttackFromDisk();
  } catch (_e) {}
  return {
    ok: true,
    command: state.command,
    commandRaw: state.commandRaw,
    commandDisplay: state.commandDisplay,
    running: state.running,
    watchPeriod: state.watchPeriod,
    lastPeriodRun: state.lastPeriodRun,
    lastSummary: state.lastSummary,
    lastError: state.lastError,
    lastAttackText: state.lastAttackText,
    lastAttackKind: state.lastAttackKind,
    lastAttackAt: state.lastAttackAt,
    lastAttackPeriod: state.lastAttackPeriod,
    lastCodesText: state.lastCodesText,
    lastCodesMeta: state.lastCodesMeta,
    lastOk: state.lastOk,
    pendingHit: state.pendingHit
      ? {
          kind: state.pendingHit.kind || "三定",
          targetPeriod: state.pendingHit.targetPeriod,
          comboName: state.pendingHit.comboName,
          count: Array.isArray(state.pendingHit.codes) ? state.pendingHit.codes.length : 0
        }
      : null,
    lastHit: state.lastHit,
    pendingByKind: {
      三定: state.pendingByKind && state.pendingByKind["三定"]
        ? {
            targetPeriod: state.pendingByKind["三定"].targetPeriod,
            comboName: state.pendingByKind["三定"].comboName,
            count: Array.isArray(state.pendingByKind["三定"].codes)
              ? state.pendingByKind["三定"].codes.length
              : 0
          }
        : null,
      四定: state.pendingByKind && state.pendingByKind["四定"]
        ? { targetPeriod: state.pendingByKind["四定"].targetPeriod }
        : null
    },
    lastByKind: state.lastByKind || { 三定: null, 四定: null },
    logs: state.logs.slice(-40)
  };
}

function httpJson(url, opts) {
  opts = opts || {};
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    const body = opts.body ? JSON.stringify(opts.body) : null;
    const req = http.request(
      {
        hostname: u.hostname,
        port: u.port || 80,
        path: u.pathname + u.search,
        method: opts.method || "GET",
        headers: Object.assign(
          { Accept: "application/json" },
          body
            ? { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(body) }
            : {},
          opts.headers || {}
        ),
        timeout: opts.timeout || 30000
      },
      (res) => {
        let buf = "";
        res.setEncoding("utf8");
        res.on("data", (c) => (buf += c));
        res.on("end", () => {
          let data = null;
          try {
            data = JSON.parse(buf);
          } catch (_e) {
            data = { raw: buf.slice(0, 200) };
          }
          resolve({ status: res.statusCode || 0, headers: res.headers, data });
        });
      }
    );
    req.on("error", reject);
    req.on("timeout", () => {
      req.destroy();
      reject(new Error("timeout"));
    });
    if (body) req.write(body);
    req.end();
  });
}

function cookieFromSetCookie(setCookie) {
  const arr = Array.isArray(setCookie) ? setCookie : setCookie ? [setCookie] : [];
  return arr
    .map((s) => String(s).split(";")[0])
    .filter(Boolean)
    .join("; ");
}

async function fetchPanelPeriod() {
  let lastErr = null;
  for (const base of PANEL_BASES) {
    try {
      const login = await httpJson(base.replace(/\/$/, "") + "/login", {
        method: "POST",
        body: { password: PANEL_PASSWORD }
      });
      const cookie = cookieFromSetCookie(login.headers && login.headers["set-cookie"]);
      const st = await httpJson(base.replace(/\/$/, "") + "/state", {
        headers: cookie ? { Cookie: cookie } : {}
      });
      const data = st.data || {};
      const latestRec = data.latestRecord || data.latest || {};
      const period =
        data.sharedHistoryLatestPeriod ||
        data.sharedHistoryRdsLatestPeriod ||
        data.latestPeriod ||
        data.currentPeriod ||
        data.period ||
        latestRec.period ||
        latestRec.uid ||
        (data.lastSync && (data.lastSync.latestPeriod || data.lastSync.period)) ||
        (Array.isArray(data.history) && data.history[0] && (data.history[0].period || data.history[0].uid)) ||
        "";
      if (period) return String(period);
      lastErr = new Error("面板无期号 @" + base);
    } catch (e) {
      lastErr = e;
    }
  }
  throw lastErr || new Error("面板不可用");
}

async function pollLoop() {
  try {
    const period = await fetchPanelPeriod();
    state._pollErr = "";
    if (!period) return;

    // 首次只登记期号，不自动跑（避免一开粘贴板就狂跑）
    if (!state.watchPeriod) {
      state.watchPeriod = period;
      log("已监视开奖期号: " + period + "（命令不换时，下一期开奖会自动续跑）");
      saveState();
      try {
        await tryJudgePendingHit(period);
      } catch (_e) {}
      return;
    }

    if (period === state.watchPeriod) {
      // 同期也尝试核验（防止上次取号失败）
      try {
        await tryJudgePendingHit(period);
      } catch (_e) {}
      return;
    }

    const prev = state.watchPeriod;
    state.watchPeriod = period;
    log("新一期开奖: " + prev + " → " + period);
    saveState();

    // 先核验上一轮出码中/不中，再自动续跑
    try {
      await tryJudgePendingHit(period);
    } catch (e) {
      log("出码核验失败: " + (e && e.message ? e.message : e));
    }

    // 命令还在且未换：接着跑；若上轮未完则登记补跑，绝不静默罢工
    if (state.command && !state.running) {
      await runCommand("新期开奖自动续跑 " + period);
    } else if (!state.command) {
      log("有新期，但当前停工，不跑");
    } else {
      state.pendingRerun = true;
      state.pendingRerunReason = "新期开奖自动续跑 " + period;
      log("有新期，上轮未完 → 已登记结束后补跑 " + period);
    }
  } catch (e) {
    if (!state._pollErr || state._pollErr !== String(e.message || e)) {
      state._pollErr = String(e.message || e);
      log("期号监视暂失败: " + state._pollErr);
    }
  } finally {
    setTimeout(pollLoop, POLL_MS);
  }
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let buf = "";
    req.setEncoding("utf8");
    req.on("data", (c) => (buf += c));
    req.on("end", () => resolve(buf));
    req.on("error", reject);
  });
}

function send(res, code, data, type) {
  const body = type === "html" ? data : JSON.stringify(data);
  res.writeHead(code, {
    "Content-Type": (type === "html" ? "text/html" : "application/json") + "; charset=utf-8",
    "Cache-Control": "no-store"
  });
  res.end(body);
}

function loadPersistedCommand() {
  // 优先命令.txt；否则从状态恢复，避免重启后莫名停工
  try {
    if (fs.existsSync(CMD_FILE)) {
      const raw = fs.readFileSync(CMD_FILE, "utf8").trim();
      if (raw) {
        setCommand(raw, false);
        if (state.command) {
          log("已恢复命令「" + state.commandDisplay + "」，新期会自动续跑（不罢工）");
        }
        return;
      }
    }
  } catch (_e) {}
  try {
    if (fs.existsSync(STATE_FILE)) {
      const j = JSON.parse(fs.readFileSync(STATE_FILE, "utf8"));
      const raw = String((j && (j.commandRaw || j.command)) || "").trim();
      if (raw && raw !== "停" && raw !== "stop") {
        setCommand(raw, false);
        if (state.command) {
          log("已从状态恢复命令「" + state.commandDisplay + "」，新期会自动续跑");
        }
        return;
      }
    }
  } catch (_e2) {}
  setCommand("停", false);
}

const server = http.createServer(async (req, res) => {
  const u = new URL(req.url || "/", "http://127.0.0.1");
  try {
    if (req.method === "GET" && (u.pathname === "/" || u.pathname === "/index.html")) {
      send(res, 200, fs.readFileSync(HTML_FILE, "utf8"), "html");
      return;
    }
    if (req.method === "GET" && u.pathname === "/api/status") {
      send(res, 200, publicStatus());
      return;
    }
    if (req.method === "POST" && u.pathname === "/api/command") {
      const raw = await readBody(req);
      let body = {};
      try {
        body = JSON.parse(raw || "{}");
      } catch (_e) {
        body = {};
      }
      const out = setCommand(body.command, body.runNow !== false);
      send(res, out.ok ? 200 : 400, out);
      return;
    }
    send(res, 404, { ok: false, message: "not found" });
  } catch (e) {
    send(res, 500, { ok: false, message: e && e.message ? e.message : String(e) });
  }
});

server.on("error", (e) => {
  console.error("Server error:", e && e.message ? e.message : e);
  console.error("If port in use, close old paste-board window first.");
  try {
    if (process.platform === "win32") {
      // keep console visible when double-clicked
    }
  } catch (_e) {}
  setTimeout(() => process.exit(1), 5000);
});

server.listen(PORT, "127.0.0.1", () => {
  // 启动必清锁，防止异常退出后带着 running=true 永久罢工
  state.running = false;
  state.runStartedAt = 0;
  state.activeChild = null;
  state.pendingRerun = false;
  loadHitState();
  loadPersistedCommand();
  try {
    loadAttackFromDisk();
  } catch (_e) {}
  log(
    "粘贴板已启动 http://127.0.0.1:" +
      PORT +
      "/ · 子进程超时" +
      Math.round(CHILD_TIMEOUT_MS / 1000) +
      "s · 请保持黑窗开着"
  );
  setTimeout(pollLoop, 3000);
  // 进程级兜底：未捕获异常也尽量别默默死掉前打日志
  process.on("uncaughtException", (e) => {
    try {
      log("未捕获异常（将由黑窗重启拉起）: " + (e && e.message ? e.message : e));
    } catch (_e) {}
  });
  process.on("unhandledRejection", (e) => {
    try {
      log(
        "未处理 Promise（不自动停工）: " +
          (e && e.message ? e.message : String(e))
      );
    } catch (_e) {}
  });
  if (process.platform === "win32") {
    spawn("cmd.exe", ["/c", "start", "", "http://127.0.0.1:" + PORT + "/"], {
      windowsHide: true,
      detached: true,
      stdio: "ignore"
    }).unref();
  }
});
