@echo off
chcp 65001 >nul
cd /d "%~dp0"
set /p AMT=输入金额（例 0.5）: 
if "%AMT%"=="" (
  echo 金额不能为空
  pause
  exit /b 1
)
python four_throw_robot.py --codes-file remain.txt --amount %AMT% --page-from 1 --page-to 11 --dry-write 预览输出.txt
echo.
echo 已写出 预览输出.txt
pause
