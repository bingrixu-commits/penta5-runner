@echo off
chcp 65001 >nul
cd /d "%~dp0"
set AMT=
for /f "usebackq delims=" %%A in (`python -c "import json;print(json.load(open('four_throw_urls.json',encoding='utf-8-sig')).get('amount') or '')"`) do set AMT=%%A
if "%AMT%"=="" set /p AMT=配置里金额为空，请输入金额（例 0.5）: 
if "%AMT%"=="" (
  echo 金额不能为空
  pause
  exit /b 1
)
echo 使用金额 %AMT%
python four_throw_robot.py --codes-file remain.txt --amount %AMT% --page-from 1 --page-to 11 --dry-write 预览输出.txt
echo.
echo 已写出 预览输出.txt
pause
