#!/usr/bin/env node
/**
 * 本机工具：抓四定转攻击语（单独入口，不动三定）
 *
 * 只抓面板 http://8.210.5.221:3001/panel （登录 /state）：
 *   - 千/百/十/个 命中最高 2 位，各从 0123456789 删 1 码
 *   - 除对数YY：开奖号码下「三对数排除 → 本期排除」
 *   - 合尾：面板合尾命中率最高 2 条 → 保留池
 *   - 二数合 / 三数合：取二兄弟框架两项（anyTwoHeweiHit / anyThreeHeweiHit）
 *
 * 格式例：
 *   千…百…十…个…四定除对数38千百十合012356789千百十个合012345678二数合02468三数合01245各
 *
 *   node 抓四定转攻击语.js
 */
"use strict";

const fs = require("fs");
const path = require("path");
const http = require("http");

const FULL_POOL = "0123456789";
const PANEL_PASSWORD = process.env.PANEL_PASSWORD || "147258";
const PANEL_BASES = (
  process.env.PANEL_BASES ||
  "http://8.210.5.221:3001,http://127.0.0.1:3001"
)
  .split(",")
  .map((s) => s.trim())
  .filter(Boolean);

const POS_ORDER = ["wan", "qian", "bai", "shi"];
const POS_META = {
  wan: { label: "千" },
  qian: { label: "百" },
  bai: { label: "十" },
  shi: { label: "个" }
};

/** 面板合尾候选（三数合尾 + 千百十个合） */
const HEWEI_CANDS = [
  { label: "千百十合", keys: ["wanQianBai", "wanQianBaiFreq"] },
  { label: "百十个合", keys: ["qianBaiShi", "qianBaiShiFreq"] },
  { label: "千百个合", keys: ["wanQianGe", "wanQianGeFreq"] },
  { label: "千十个合", keys: ["wanBaiShi", "wanBaiShiFreq"] },
  { label: "千百十个合", keys: ["wanQianBaiShi"] }
];

function stripDigit(pool, digit) {
  const d = String(digit == null ? "" : digit).replace(/\D/g, "").slice(0, 1);
  if (!d) return pool;
  return String(pool).split(d).join("");
}

function num(v, fb) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fb;
}

function fmtRate(v) {
  const n = num(v, -1);
  return n < 0 ? "--" : n.toFixed(2) + "%";
}

function cookieFromSetCookie(setCookie) {
  const arr = Array.isArray(setCookie) ? setCookie : setCookie ? [setCookie] : [];
  return arr
    .map((s) => String(s).split(";")[0])
    .filter(Boolean)
    .join("; ");
}

function httpJson(url, opts) {
  opts = opts || {};
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    const body = opts.body ? JSON.stringify(opts.body) : null;
    const req = http.request(
      {
        hostname: u.hostname,
        port: u.port || (u.protocol === "https:" ? 443 : 80),
        path: u.pathname + u.search,
        method: opts.method || "GET",
        headers: Object.assign(
          { Accept: "application/json" },
          body
            ? { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(body) }
            : {},
          opts.headers || {}
        ),
        timeout: opts.timeout || 60000
      },
      (res) => {
        let buf = "";
        res.setEncoding("utf8");
        res.on("data", (c) => (buf += c));
        res.on("end", () => {
          let data = null;
          try {
            data = JSON.parse(buf);
          } catch (_e) {
            data = { raw: buf.slice(0, 300) };
          }
          if (res.statusCode && res.statusCode >= 400) {
            reject(
              new Error(
                "HTTP " +
                  res.statusCode +
                  " " +
                  ((data && (data.error || data.message)) || buf.slice(0, 120))
              )
            );
            return;
          }
          resolve({ headers: res.headers, data });
        });
      }
    );
    req.on("error", reject);
    req.on("timeout", () => {
      req.destroy();
      reject(new Error("timeout"));
    });
    if (body) req.write(body);
    req.end();
  });
}

async function fetchPanelState() {
  const errors = [];
  for (const base of PANEL_BASES) {
    const root = String(base || "").replace(/\/$/, "");
    try {
      const login = await httpJson(root + "/login", {
        method: "POST",
        body: { password: PANEL_PASSWORD },
        timeout: 15000
      });
      const cookie = cookieFromSetCookie(login.headers && login.headers["set-cookie"]);
      const resp = await httpJson(root + "/state", {
        timeout: 60000,
        headers: cookie ? { Cookie: cookie } : {}
      });
      if (!resp.data || resp.data.ok === false) {
        throw new Error((resp.data && resp.data.error) || "state not ok");
      }
      return { base: root, state: resp.data, panelUrl: root + "/panel" };
    } catch (e) {
      errors.push(root + " → " + (e && e.message ? e.message : e));
    }
  }
  throw new Error("面板登录/拉 state 失败：\n" + errors.join("\n"));
}

function posRate(row) {
  if (!row) return -1;
  const r120 = num(row.rate120, -1);
  if (r120 >= 0) return r120;
  const score = num(row.score, -1);
  if (score >= 0) return score;
  const r30 = num(row.rate30, -1);
  if (r30 >= 0) return r30;
  return -1;
}

function heweiRate(row) {
  if (!row) return -1;
  const st = row.stability && typeof row.stability === "object" ? row.stability : {};
  const r120 = num(row.rate120 != null ? row.rate120 : st.lower120, -1);
  if (r120 >= 0) return r120;
  const perf = row.performance && typeof row.performance === "object" ? row.performance : {};
  const pr = num(perf.rate, -1);
  if (pr >= 0) return pr;
  return posRate(row);
}

function pickTop2Positions(state) {
  const pred = (state && state.currentPrediction) || {};
  const four = pred.fourPosExclude || {};
  const items = Array.isArray(four.items) ? four.items : [];
  const byKey = Object.create(null);
  items.forEach((it) => {
    if (!it || !POS_META[it.key]) return;
    const digit = String(it.code == null ? "" : it.code).replace(/\D/g, "").slice(0, 1);
    if (!/^\d$/.test(digit)) return;
    byKey[it.key] = {
      key: it.key,
      label: POS_META[it.key].label,
      digit,
      rate: posRate(it),
      score: num(it.score, -1),
      source: "panel-fourPosExclude"
    };
  });

  // 补洞：positionKills
  const kills = pred.positionKills || {};
  POS_ORDER.forEach((k) => {
    if (byKey[k] || !kills[k]) return;
    const row = kills[k];
    const digit = String(
      row.selectedDigit || row.primaryDigit || row.recommendDigit || row.main || ""
    )
      .replace(/\D/g, "")
      .slice(0, 1);
    if (!/^\d$/.test(digit)) return;
    byKey[k] = {
      key: k,
      label: POS_META[k].label,
      digit,
      rate: posRate(row),
      score: num(row.score, -1),
      source: "panel-positionKills"
    };
  });

  const all = POS_ORDER.map((k) => byKey[k]).filter(Boolean);
  all.sort((a, b) => {
    const d = b.rate - a.rate;
    if (d !== 0) return d;
    return b.score - a.score;
  });
  const top2 = all.slice(0, 2);
  return { all, top2 };
}

/** 合尾：面板命中率最高 2 条（同标签只留最高一条） */
function pickTop2HeweiKeep(state) {
  const pred = (state && state.currentPrediction) || {};
  const ind = pred.independentHeweiKills || {};
  const byLabel = Object.create(null);

  HEWEI_CANDS.forEach((def) => {
    (def.keys || []).forEach((hk) => {
      const row = ind[hk];
      if (!row) return;
      const digit = String(row.killDigit || row.primaryDigit || "").replace(/\D/g, "").slice(0, 1);
      if (!/^\d$/.test(digit)) return;
      const cand = {
        key: hk,
        label: def.label,
        killDigit: digit,
        keepPool: stripDigit(FULL_POOL, digit),
        rate: heweiRate(row),
        name: row.label || def.label,
        source: "panel-hewei." + hk
      };
      const prev = byLabel[def.label];
      if (!prev || cand.rate > prev.rate) byLabel[def.label] = cand;
    });
  });

  const ranked = Object.keys(byLabel).map((k) => byLabel[k]);
  ranked.sort((a, b) => {
    const d = b.rate - a.rate;
    if (d !== 0) return d;
    return String(a.label).localeCompare(String(b.label));
  });
  const withRate = ranked.filter((c) => c.rate >= 0);
  const pool = withRate.length ? withRate : ranked;
  return { top2: pool.slice(0, 2), ranked };
}

/** 除对数：开奖号码下「三对数排除 → 本期排除」 */
function pickPair(state) {
  const dui =
    (state && state.threeDuishuRecommendation) ||
    ((state && state.currentPrediction && state.currentPrediction.threeDuishu) ||
      {});
  const pair = String(dui.selectedPair || dui.selectedPairCode || "")
    .replace(/\D/g, "")
    .slice(0, 2);
  const candidates = Array.isArray(dui.pairs)
    ? dui.pairs.join("|")
    : Array.isArray(dui.pairCodes)
      ? dui.pairCodes.join("|")
      : "";
  return {
    pair: /^\d{2}$/.test(pair) ? pair : "",
    shot: dui.shot || "",
    candidates,
    period: dui.period || "",
    source: "panel-开奖下本期排除"
  };
}

/** 取二兄弟框架：二数合 + 三数合 */
function pickBrotherTwoThree(state) {
  const pred = (state && state.currentPrediction) || {};
  const extras =
    pred.extraKills ||
    (pred.detail && pred.detail.extraKills) ||
    {};

  function readExtra(key) {
    const row = extras[key];
    if (!row || typeof row !== "object") return null;
    const code = String(
      row.value != null ? row.value : row.code != null ? row.code : ""
    ).replace(/\D/g, "");
    if (!code || code === "--") return null;
    return {
      key,
      code,
      rate: heweiRate(row),
      source: "panel-取二兄弟." + key
    };
  }

  return {
    two: readExtra("anyTwoHeweiHit"),
    three: readExtra("anyThreeHeweiHit")
  };
}

function buildFourDingAttack(opts) {
  const pools = opts.pools || {};
  const pair = opts.pair || "";
  const heweis = Array.isArray(opts.heweis) ? opts.heweis : [];
  const twoCode = opts.twoCode || "";
  const threeCode = opts.threeCode || "";
  let text = "";
  POS_ORDER.forEach((k) => {
    text += POS_META[k].label + (pools[k] || FULL_POOL);
  });
  text += "四定";
  if (/^\d{2}$/.test(pair)) text += "除对数" + pair;
  heweis.forEach((h) => {
    if (!h || !h.label) return;
    text += h.label + (h.keepPool || FULL_POOL);
  });
  if (twoCode) text += "二数合" + twoCode;
  if (threeCode) text += "三数合" + threeCode;
  text += "各";
  return text;
}

function latestPeriod(state) {
  return String(
    state.sharedHistoryLatestPeriod ||
      state.sharedHistoryRdsLatestPeriod ||
      (state.latestRecord && (state.latestRecord.period || state.latestRecord.uid)) ||
      (state.threeDuishuRecommendation && state.threeDuishuRecommendation.period) ||
      ""
  );
}

async function main() {
  console.log("【抓四定转攻击语】定位顶2 + 合尾顶2 + 除对数本期排除 + 二兄弟二三数合");
  const panel = await fetchPanelState();
  const state = panel.state;
  const period = latestPeriod(state);
  console.log("面板: " + panel.panelUrl + (period ? "  期号 " + period : ""));

  const { all, top2 } = pickTop2Positions(state);
  if (top2.length < 2) {
    console.error("定位不足 2 个，无法生成四定攻击语");
    process.exit(2);
  }

  const pools = Object.create(null);
  POS_ORDER.forEach((k) => {
    pools[k] = FULL_POOL;
  });
  top2.forEach((p) => {
    pools[p.key] = stripDigit(FULL_POOL, p.digit);
  });

  const heweiPick = pickTop2HeweiKeep(state);
  const heweis = heweiPick.top2;
  const dui = pickPair(state);
  const brother = pickBrotherTwoThree(state);

  if (heweis.length < 2) {
    console.error("面板合尾不足 2 条，无法按口径生成");
    process.exitCode = 4;
  }
  if (!brother.two || !brother.three) {
    console.error("面板取二兄弟未取到二数合/三数合");
    process.exitCode = Math.max(process.exitCode || 0, 5);
  }

  const text = buildFourDingAttack({
    pools,
    pair: dui.pair,
    heweis,
    twoCode: brother.two ? brother.two.code : "",
    threeCode: brother.three ? brother.three.code : ""
  });

  const detail = [
    "【抓四定转攻击语 · 可复制】",
    "流程: 定位顶2 → 除对数(开奖下本期排除) → 合尾命中最高2 → 二兄弟二数合+三数合",
    "基准期: " + (period || "--"),
    "面板: " + panel.panelUrl,
    "②定位顶2: " +
      top2
        .map((p) => p.label + "-" + p.digit + "(" + fmtRate(p.rate) + ")")
        .join(" ") +
      " ｜候选 " +
      all
        .map((p) => p.label + p.digit + "@" + fmtRate(p.rate))
        .join(","),
    "合尾顶2: " +
      (heweis.length
        ? heweis
            .map(
              (h) =>
                "杀" +
                h.killDigit +
                " → " +
                h.label +
                h.keepPool +
                " (" +
                fmtRate(h.rate) +
                ") ← " +
                h.source
            )
            .join(" ｜ ")
        : "未取到") +
      (heweiPick.ranked.length
        ? " ｜候选 " +
          heweiPick.ranked
            .map((c) => c.label.replace(/合$/, "") + c.killDigit + "@" + fmtRate(c.rate))
            .join(",")
        : ""),
    "对数: 除对数" +
      (dui.pair || "??") +
      (dui.candidates ? " ｜候选 " + dui.candidates : "") +
      (dui.shot ? " ｜" + dui.shot : "") +
      " ← " +
      dui.source,
    "二兄弟: " +
      (brother.two
        ? "二数合" + brother.two.code + "(" + fmtRate(brother.two.rate) + ")"
        : "二数合--") +
      " ｜ " +
      (brother.three
        ? "三数合" + brother.three.code + "(" + fmtRate(brother.three.rate) + ")"
        : "三数合--"),
    "池子: " +
      POS_ORDER.map((k) => POS_META[k].label + pools[k]).join(" "),
    "",
    text,
    ""
  ].join("\n");

  console.log(detail);

  const lineFile = path.join(__dirname, "攻击语一行-四定.txt");
  const fullFile = path.join(__dirname, "当期攻击语-四定.txt");
  const lineFileEn = path.join(__dirname, "attack-four-line.txt");
  const fullFileEn = path.join(__dirname, "attack-four-full.txt");
  fs.writeFileSync(lineFile, text + "\n", "utf8");
  fs.writeFileSync(fullFile, detail, "utf8");
  fs.writeFileSync(lineFileEn, text + "\n", "utf8");
  fs.writeFileSync(fullFileEn, detail, "utf8");
  console.log("已写入: " + fullFile);
  console.log("已写入: " + lineFile);
  console.log("已写入: " + lineFileEn);
  console.log("可复制一行: " + lineFileEn);

  if (!dui.pair) process.exitCode = 3;
  if (heweis.length < 2) process.exitCode = Math.max(process.exitCode || 0, 4);
  if (!brother.two || !brother.three) {
    process.exitCode = Math.max(process.exitCode || 0, 5);
  }
}

main().catch((e) => {
  console.error(e && e.stack ? e.stack : e);
  process.exit(1);
});
