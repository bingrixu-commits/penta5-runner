@echo off
chcp 65001 >nul
cd /d "%~dp0"
title huishan-to-498
echo 本机回删：攻击语排除 → 历史命中删 → 硬删到498
echo.
where node >nul 2>nul
if errorlevel 1 (
  echo [ERROR] 未找到 node
  pause
  exit /b 1
)
node "%~dp0本机回删.js" --out
if errorlevel 1 (
  echo [ERROR] 回删失败
  pause
  exit /b 1
)
echo.
if exist "%~dp0回删结果-第1批.txt" (
  type "%~dp0回删结果-第1批.txt" | clip
  echo 第1批已复制到剪贴板
)
echo.
pause
