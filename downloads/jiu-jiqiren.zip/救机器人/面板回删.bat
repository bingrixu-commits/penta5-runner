@echo off
chcp 65001 >nul
cd /d "%~dp0"
title 面板回删-第二套
echo ========================================
echo   面板回删（第二套 · 旧码200剩800）
echo   攻击语：攻击语一行.txt 或下面传参
echo   结果：面板回删结果*.txt（不碰第一套）
echo ========================================
echo.
where node >nul 2>nul
if errorlevel 1 (
  echo [ERROR] 未找到 node
  pause
  exit /b 1
)
node "%~dp0面板回删.js" --out %*
echo.
pause
