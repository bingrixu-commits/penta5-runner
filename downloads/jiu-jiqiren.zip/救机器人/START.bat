@echo off
chcp 65001 >nul
cd /d "%~dp0"
title paste-board
echo 启动粘贴板（推荐入口）
echo.
call "%~dp0粘贴板.bat"
