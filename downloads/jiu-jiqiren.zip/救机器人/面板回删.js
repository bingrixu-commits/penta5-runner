#!/usr/bin/env node
/**
 * 第二套：面板回删（与第一套「命中删498」分开，不混用）
 *
 * 1) 攻击语排除（你指定 / 攻击语一行.txt）
 * 2) 真实旧码回删（最新→更早）
 * 3) 回删至剩 800（排除后≤800 原样保留）
 *
 * 结果只写：面板回删结果*.txt / 面板回删结果.json
 * 绝不覆盖第一套的 回删结果*
 */
"use strict";

const fs = require("fs");
const path = require("path");
const http = require("http");
const vm = require("vm");

const DIR = __dirname;
const HIST_FILE = path.join(DIR, "开奖历史.json");
const ATTACK_LINE = path.join(DIR, "攻击语一行.txt");
const OUT_TXT = path.join(DIR, "面板回删结果.txt");
const OUT_TXT_1 = path.join(DIR, "面板回删结果-第1批.txt");
const OUT_TXT_2 = path.join(DIR, "面板回删结果-第2批.txt");
const OUT_JSON = path.join(DIR, "面板回删结果.json");
const HIST_LIMIT = Math.max(200, Number(process.env.HIST_LIMIT || 2500));
const BATCH1_SIZE = 300;
const EXPECT_RETRY = Math.max(1, Number(process.env.HIST_EXPECT_RETRY || 8));
const EXPECT_RETRY_MS = Math.max(1000, Number(process.env.HIST_EXPECT_RETRY_MS || 5000));
const PANEL_PASSWORD = process.env.PANEL_PASSWORD || "147258";
const PANEL_BASES = (
  process.env.PANEL_BASES ||
  "http://8.210.5.221:3001,http://127.0.0.1:3001"
)
  .split(",")
  .map((s) => s.trim())
  .filter(Boolean);

function findConvertJs() {
  const cands = [
    path.join(DIR, "txt_attack_convert.js"),
    path.resolve(DIR, "../../penta5-runner/txt_attack_convert.js"),
    path.resolve(DIR, "../penta5-runner/txt_attack_convert.js"),
    "/root/penta5-runner/txt_attack_convert.js",
    path.resolve(process.cwd(), "penta5-runner/txt_attack_convert.js")
  ];
  for (const p of cands) if (fs.existsSync(p)) return p;
  return null;
}

function loadApi() {
  const file = findConvertJs();
  if (!file) throw new Error("未找到 txt_attack_convert.js");
  const code = fs.readFileSync(file, "utf8");
  const sb = { console, module: { exports: {} }, exports: {}, require };
  sb.global = sb;
  vm.runInNewContext(code, sb, { filename: file });
  const api = sb.global.Penta5AttackTxtConvert;
  if (!api || typeof api.convertThreeDingBackDelete !== "function") {
    throw new Error("转换库未导出 convertThreeDingBackDelete");
  }
  return { api, file };
}

function httpJson(url, opts) {
  opts = opts || {};
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    const body = opts.body ? JSON.stringify(opts.body) : null;
    const req = http.request(
      {
        hostname: u.hostname,
        port: u.port || (u.protocol === "https:" ? 443 : 80),
        path: u.pathname + u.search,
        method: opts.method || "GET",
        headers: Object.assign(
          { Accept: "application/json" },
          body
            ? { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(body) }
            : {},
          opts.headers || {}
        ),
        timeout: opts.timeout || 180000
      },
      (res) => {
        let buf = "";
        res.setEncoding("utf8");
        res.on("data", (c) => (buf += c));
        res.on("end", () => {
          let data = null;
          try {
            data = JSON.parse(buf);
          } catch (_e) {
            data = { raw: buf.slice(0, 300) };
          }
          if (res.statusCode && res.statusCode >= 400) {
            const msg =
              (data && (data.error || data.message || data.reason)) || buf.slice(0, 160);
            reject(new Error("HTTP " + res.statusCode + " " + url + " :: " + msg));
            return;
          }
          resolve({ status: res.statusCode || 0, headers: res.headers, data });
        });
      }
    );
    req.on("error", reject);
    req.on("timeout", () => {
      req.destroy();
      reject(new Error("timeout " + url));
    });
    if (body) req.write(body);
    req.end();
  });
}

function cookieFromSetCookie(setCookie) {
  const arr = Array.isArray(setCookie) ? setCookie : setCookie ? [setCookie] : [];
  return arr
    .map((s) => String(s).split(";")[0])
    .filter(Boolean)
    .join("; ");
}

async function fetchPanelHistoryOnce(base, expectPeriod) {
  const root = String(base || "").replace(/\/$/, "");
  const login = await httpJson(root + "/login", {
    method: "POST",
    body: { password: PANEL_PASSWORD },
    timeout: 15000
  });
  const cookie = cookieFromSetCookie(login.headers && login.headers["set-cookie"]);
  const hist = await httpJson(root + "/converter-history?limit=" + HIST_LIMIT, {
    headers: cookie ? { Cookie: cookie } : {},
    timeout: 180000
  });
  const data = hist.data || {};
  const rows = Array.isArray(data.history) ? data.history : [];
  if (data.ok === false) {
    throw new Error(data.error || data.message || "converter-history 不可用");
  }
  if (rows.length < 200) {
    throw new Error("历史不足 200 期（实得 " + rows.length + "）@" + root);
  }
  const first = rows[0] || {};
  const firstPeriod = String(first.period || first.uid || "");
  const sharedSource = String(data.source || data.sharedHistorySource || "").toLowerCase();
  const sharedPeriod = String(
    data.sharedPeriod || data.sharedHistoryLatestPeriod || firstPeriod || ""
  );
  const rdsPeriod = String(data.rdsPeriod || data.sharedHistoryRdsLatestPeriod || "");
  if (sharedSource && sharedSource !== "rds") {
    throw new Error("共享历史来源不是 RDS（" + sharedSource + "）@" + root);
  }
  if (rdsPeriod && sharedPeriod && sharedPeriod !== rdsPeriod) {
    throw new Error(
      "共享期 " + sharedPeriod + " 尚未追平 RDS " + rdsPeriod + " @" + root
    );
  }
  if (expectPeriod) {
    const want = String(expectPeriod);
    if (firstPeriod !== want) {
      throw new Error(
        "历史首期 " + (firstPeriod || "空") + " ≠ 期望期 " + want + "（RDS 未追平）@" + root
      );
    }
    if (sharedPeriod && sharedPeriod !== want) {
      throw new Error(
        "共享最新期 " + sharedPeriod + " ≠ 期望期 " + want + " @" + root
      );
    }
  }
  const firstNums = Array.isArray(first.numbers) ? first.numbers : [];
  if (
    !/^\d+$/.test(firstPeriod) ||
    !String(first.opentime || "").trim() ||
    firstNums.length < 4 ||
    firstNums.slice(0, 4).some((v) => !/^\d$/.test(String(v)))
  ) {
    throw new Error("当前期记录缺期号/开奖时间/四位号码 @" + root);
  }
  return {
    source: root,
    sharedHistorySource: sharedSource || "rds",
    sharedHistoryRdsLatestPeriod: rdsPeriod || firstPeriod,
    sharedHistoryLatestPeriod: sharedPeriod || firstPeriod,
    history: rows.slice(0, HIST_LIMIT),
    updatedAt: new Date().toISOString()
  };
}

async function syncAliyunToLocal(expectPeriod) {
  let lastErr = null;
  for (let attempt = 1; attempt <= EXPECT_RETRY; attempt++) {
    for (const base of PANEL_BASES) {
      try {
        const pack = await fetchPanelHistoryOnce(base, expectPeriod);
        fs.writeFileSync(
          HIST_FILE,
          JSON.stringify(
            {
              updatedAt: pack.updatedAt,
              source: pack.source,
              sharedHistorySource: pack.sharedHistorySource,
              sharedHistoryRdsLatestPeriod: pack.sharedHistoryRdsLatestPeriod,
              sharedHistoryLatestPeriod: pack.sharedHistoryLatestPeriod,
              expectPeriod: expectPeriod || "",
              refreshedFromRds: true,
              limit: HIST_LIMIT,
              history: pack.history
            },
            null,
            2
          ),
          "utf8"
        );
        return pack;
      } catch (e) {
        lastErr = e;
      }
    }
    if (attempt < EXPECT_RETRY) {
      console.log(
        "历史未追平，" +
          Math.round(EXPECT_RETRY_MS / 1000) +
          "s 后重试 " +
          (attempt + 1) +
          "/" +
          EXPECT_RETRY +
          "：" +
          (lastErr && lastErr.message ? lastErr.message : lastErr)
      );
      await new Promise((r) => setTimeout(r, EXPECT_RETRY_MS));
    }
  }
  throw lastErr || new Error("阿里云历史拉取失败");
}

function loadLocalHistory() {
  if (!fs.existsSync(HIST_FILE)) throw new Error("本地无历史文件: " + HIST_FILE);
  const j = JSON.parse(fs.readFileSync(HIST_FILE, "utf8"));
  const history = Array.isArray(j.history) ? j.history : [];
  if (!history.length) throw new Error("本地历史为空");
  return {
    source: j.source || "local",
    sharedHistorySource: j.sharedHistorySource || "local",
    sharedHistoryRdsLatestPeriod: j.sharedHistoryRdsLatestPeriod || "",
    history: history.slice(0, HIST_LIMIT),
    updatedAt: j.updatedAt || ""
  };
}

function parseArgs(argv) {
  const out = { text: "", out: false, offline: false, help: false, expectPeriod: "" };
  for (let i = 2; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--text") out.text = String(argv[++i] || "");
    else if (a === "--out") out.out = true;
    else if (a === "--offline") out.offline = true;
    else if (a === "--expect-period") out.expectPeriod = String(argv[++i] || "").trim();
    else if (a === "--help" || a === "-h") out.help = true;
    else if (!a.startsWith("-") && !out.text) out.text = a;
  }
  return out;
}

function loadAttackText(forced) {
  if (forced && String(forced).trim()) return String(forced).trim();
  if (fs.existsSync(ATTACK_LINE)) {
    const line = fs
      .readFileSync(ATTACK_LINE, "utf8")
      .split(/\r?\n/)
      .map((s) => s.trim())
      .filter(Boolean)
      .pop();
    if (line) return line;
  }
  throw new Error("无攻击语：请先跑抓码写出 攻击语一行.txt，或 --text 传入");
}

function packGroup(api, result) {
  const codes = result.codes || result.tokens || [];
  const list = Array.isArray(codes) ? codes.map(String) : [];
  const usedCombo = result.comboName || result.combo || "千百十";
  let copyParts = result.copyParts;
  if (
    (!copyParts || !copyParts.part1Text) &&
    typeof api.threeDingCopyParts === "function"
  ) {
    copyParts = api.threeDingCopyParts(list, BATCH1_SIZE, usedCombo);
  }
  const batch1 = (copyParts && copyParts.part1Tokens) || list.slice(0, BATCH1_SIZE);
  const batch2 = (copyParts && copyParts.part2Tokens) || list.slice(BATCH1_SIZE);
  const text1 =
    (copyParts && copyParts.part1Text) ||
    (typeof api.formatThreeDingGeList === "function"
      ? api.formatThreeDingGeList(batch1, null, usedCombo)
      : batch1.join(","));
  const text2 =
    (copyParts && copyParts.part2Text) ||
    (batch2.length
      ? typeof api.formatThreeDingGeList === "function"
        ? api.formatThreeDingGeList(batch2, null, usedCombo)
        : batch2.join(",")
      : "");
  const textOut =
    result.text ||
    result.attackText ||
    (typeof api.formatThreeDingGeList === "function"
      ? api.formatThreeDingGeList(list, null, usedCombo)
      : list.join(","));
  return {
    comboName: usedCombo,
    afterFilter: result.afterFilter,
    deletedUnique: result.deletedUnique,
    scanned: result.scanned,
    count: result.count != null ? result.count : list.length,
    remainFloor: result.remainFloor != null ? result.remainFloor : 800,
    stoppedAtFloor: !!result.stoppedAtFloor,
    todayKey: result.todayKey || "",
    todayPeriodCount: result.todayPeriodCount != null ? result.todayPeriodCount : null,
    scanFromPeriod: result.scanFromPeriod || "",
    scanToPeriod: result.scanToPeriod || "",
    hitSamples: result.hitSamples || [],
    label: result.label || "",
    note: result.note || "",
    batch1,
    batch2,
    batch1Text: text1,
    batch2Text: text2,
    allText: textOut,
    codes: list
  };
}

async function main() {
  const args = parseArgs(process.argv);
  if (args.help) {
    console.log(`面板回删（第二套 · 攻击语排除 → 旧码回删200剩800）

  node 面板回删.js --out
  node 面板回删.js --text "你的攻击语" --out
  node 面板回删.js --expect-period 期号 --out

1) 攻击语先排除  2) 真实旧码回删  3) 剩800
结果文件：面板回删结果*（不碰第一套 回删结果*）`);
    return;
  }

  const attack = loadAttackText(args.text);
  const expectPeriod = String(args.expectPeriod || "").trim();
  console.log("【面板回删·第二套】攻击语排除 → 旧码回删200剩800");
  console.log("攻击语: " + attack);
  if (expectPeriod) console.log("期望首期: " + expectPeriod);

  let pack;
  if (args.offline) {
    pack = loadLocalHistory();
    const first = (pack.history[0] && (pack.history[0].period || pack.history[0].uid)) || "";
    if (expectPeriod && String(first) !== expectPeriod) {
      throw new Error(
        "--offline 本地首期 " + first + " ≠ 期望期 " + expectPeriod + "（禁止用过期历史硬删）"
      );
    }
    console.log(
      "⚠ --offline 未刷新: " + HIST_FILE + (pack.updatedAt ? " @ " + pack.updatedAt : "")
    );
  } else {
    console.log(
      "从面板 /converter-history 拉 ≤" + HIST_LIMIT + " 期（强制 RDS hydrate，首期校验）…"
    );
    pack = await syncAliyunToLocal(expectPeriod);
    console.log(
      "已写入: " +
        HIST_FILE +
        " ← " +
        pack.source +
        " (" +
        (pack.sharedHistorySource || "rds") +
        ")" +
        (pack.sharedHistoryRdsLatestPeriod
          ? " rdsLatest=" + pack.sharedHistoryRdsLatestPeriod
          : "")
    );
  }

  const { api, file } = loadApi();
  console.log("转换库: " + file);
  const latest = pack.history[0] || {};
  console.log(
    "回删用本地历史: " +
      pack.history.length +
      " 期，本期起 " +
      (latest.period || "?") +
      " " +
      JSON.stringify(latest.numbers || [])
  );

  // 攻击语排除 → 真实旧码回删 → 剩800（面板口径）
  const result = api.convertThreeDingBackDelete(attack, pack.history, {});
  if (!result || result.ok === false) {
    console.error("回删失败: " + ((result && result.message) || "unknown"));
    process.exit(2);
  }

  const groups = [];
  if (result.multiCombo && Array.isArray(result.groups) && result.groups.length) {
    result.groups.forEach((g) => groups.push(packGroup(api, g)));
  } else {
    groups.push(packGroup(api, result));
  }

  const primary = groups[0];
  const summaryLines = [
    "【面板回删结果 · 攻击语排除 → 旧码回删200剩800】",
    "攻击语: " + attack,
    "期望首期: " + (expectPeriod || "--"),
    "历史文件: " + HIST_FILE,
    "拉取来源: " + pack.source + " / " + (pack.sharedHistorySource || "rds"),
    "历史期数: " + pack.history.length + "（本期 " + (latest.period || "?") + "）",
    ""
  ];
  groups.forEach((g) => {
    summaryLines.push(
      "【" +
        g.comboName +
        "】排除后 " +
        g.afterFilter +
        " → 旧码删 " +
        g.deletedUnique +
        " → 现剩 " +
        g.count +
        (Number(g.count) === 800 ? "（已到800）" : "") +
        "（扫" +
        g.scanned +
        "期）"
    );
  });
  summaryLines.push("");
  groups.forEach((g) => {
    summaryLines.push("======== " + g.comboName + " · 第1批 ========");
    summaryLines.push(g.batch1Text);
    summaryLines.push("");
    summaryLines.push("======== " + g.comboName + " · 第2批 ========");
    summaryLines.push(g.batch2Text || "（无）");
    summaryLines.push("");
  });
  const summary = summaryLines.join("\n");
  console.log(summary);

  if (args.out) {
    fs.writeFileSync(OUT_TXT, summary, "utf8");
    fs.writeFileSync(OUT_TXT_1, primary.batch1Text + (primary.batch1Text ? "\n" : ""), "utf8");
    fs.writeFileSync(OUT_TXT_2, primary.batch2Text + (primary.batch2Text ? "\n" : ""), "utf8");
    fs.writeFileSync(
      OUT_JSON,
      JSON.stringify(
        {
          ok: true,
          mode: "panel-backdelete-800",
          multiCombo: groups.length > 1,
          attack: attack,
          attackRaw: attack,
          expectPeriod: expectPeriod || "",
          historyCount: pack.history.length,
          historyFile: HIST_FILE,
          historySource: pack.source,
          latestPeriod: latest.period || "",
          comboName: primary.comboName,
          comboNames: groups.map((g) => g.comboName),
          batch1Size: BATCH1_SIZE,
          batch1Text: primary.batch1Text,
          batch2Text: primary.batch2Text,
          allText: primary.allText,
          batch1: primary.batch1,
          batch2: primary.batch2,
          codes: primary.codes,
          result: {
            afterFilter: primary.afterFilter,
            deletedUnique: primary.deletedUnique,
            scanned: primary.scanned,
            remainFloor: primary.remainFloor,
            stoppedAtFloor: primary.stoppedAtFloor,
            todayKey: primary.todayKey,
            todayPeriodCount: primary.todayPeriodCount,
            scanFromPeriod: primary.scanFromPeriod,
            scanToPeriod: primary.scanToPeriod,
            hitSamples: primary.hitSamples,
            count: primary.count,
            note: primary.note,
            label: primary.label
          },
          groups: groups
        },
        null,
        2
      ),
      "utf8"
    );
    console.log("已写入: " + OUT_TXT);
    console.log("已写入: " + OUT_JSON);
    console.log(
      "默认剪贴板=" +
        primary.comboName +
        "第1批 → " +
        OUT_TXT_1 +
        "（" +
        primary.batch1.length +
        "）"
    );
  }
}

main().catch((e) => {
  console.error("[ERROR]", e && e.message ? e.message : e);
  process.exit(1);
});
