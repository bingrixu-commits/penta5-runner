@echo off
chcp 65001 >nul
cd /d "%~dp0"
title format-huishan
echo ========================================
echo  转成投注格式：002x,004x,...各
echo ========================================
echo.
where node >nul 2>nul
if errorlevel 1 (
  echo 未找到 node
  pause
  exit /b 1
)

if not exist "%~dp0回删结果.json" if not exist "%~dp0回删结果.txt" (
  echo [!] 本文件夹还没有回删结果。
  echo     请先双击 一键回删.bat 跑一次，再点本文件。
  echo.
  pause
  exit /b 1
)

node "%~dp0把回删结果转投注格式.js"
if errorlevel 1 (
  echo 转换失败
  pause
  exit /b 1
)

echo.
echo -------- 前80个字符（应能看到逗号和x）--------
powershell -NoProfile -Command "Get-Content -LiteralPath '%~dp0回删结果-第1批.txt' -TotalCount 1 | ForEach-Object { $_.Substring(0,[Math]::Min(80,$_.Length)) }"
echo.
echo 正在用记事本打开：回删结果-第1批.txt
echo 请在记事本里找逗号 , 和末尾 各
echo.

if exist "%~dp0回删结果-第1批.txt" (
  type "%~dp0回删结果-第1批.txt" | clip
  echo 第1批已复制到剪贴板
  start "" notepad "%~dp0回删结果-第1批.txt"
) else (
  echo 未生成第1批文件
)

echo.
pause
