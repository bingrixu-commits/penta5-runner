@echo off
chcp 65001 >nul
cd /d "%~dp0"
title paste-board-keepalive
echo Paste board keepalive (auto-restart)
echo http://127.0.0.1:3792/
echo Keep this black window open.
echo.
where node >nul 2>nul
if errorlevel 1 (
  echo ERROR: node not found
  pause
  exit /b 1
)
:loop
node "%~dp0paste-board.js"
echo Process exited, restart in 5s...
timeout /t 5 /nobreak >nul
goto loop
