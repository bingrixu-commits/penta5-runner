@echo off
chcp 65001 >nul
cd /d "%~dp0"
title paste-board-keepalive
echo ========================================
echo   粘贴板（防罢工：崩溃自动拉起）
echo   http://127.0.0.1:3792/
echo   黑窗不要关；网页不要关
echo   命令贴：抓+回删
echo ========================================
echo.
where node >nul 2>nul
if errorlevel 1 (
  echo [ERROR] 未找到 node
  pause
  exit /b 1
)

:loop
echo [%date% %time%] 启动粘贴板...
node "%~dp0paste-board.js"
echo.
echo [%date% %time%] 进程退出，5 秒后自动重启（防罢工）...
timeout /t 5 /nobreak >nul
goto loop
