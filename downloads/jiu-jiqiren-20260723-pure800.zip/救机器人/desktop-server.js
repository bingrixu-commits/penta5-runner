#!/usr/bin/env node
/**
 * 三定/四定转换（桌面版）本机服务
 * 与锁定包同一口径：阿里云200校验 → 本机生成 → 今日命中删 → 不少于498
 *
 *   node 桌面版服务.js
 * 浏览器打开 http://127.0.0.1:3791/
 */
"use strict";

const fs = require("fs");
const path = require("path");
const http = require("http");
const { URL } = require("url");
const { spawn } = require("child_process");
const vm = require("vm");

const DIR = __dirname;
const PORT = Number(process.env.DESKTOP_PORT || 3791);
const HIST_FILE = path.join(DIR, "开奖历史.json");
const ATTACK_LINE = path.join(DIR, "攻击语一行.txt");
const CAND_JSON = path.join(DIR, "候选结果.json");
const OUT_TXT = path.join(DIR, "回删结果.txt");
const OUT_JSON = path.join(DIR, "回删结果.json");
const HTML_FILE = fs.existsSync(path.join(DIR, "desktop.html"))
  ? path.join(DIR, "desktop.html")
  : path.join(DIR, "三定四定转换-桌面版.html");
const HIST_LIMIT = 200;
const PANEL_PASSWORD = process.env.PANEL_PASSWORD || "147258";
const PANEL_BASES = (
  process.env.PANEL_BASES ||
  "http://8.210.5.221:3001,http://127.0.0.1:3001"
)
  .split(",")
  .map((s) => s.trim())
  .filter(Boolean);

function loadApi() {
  const file = path.join(DIR, "txt_attack_convert.js");
  if (!fs.existsSync(file)) throw new Error("缺少 txt_attack_convert.js");
  const code = fs.readFileSync(file, "utf8");
  const sb = { console, module: { exports: {} }, exports: {}, require };
  sb.global = sb;
  vm.runInNewContext(code, sb, { filename: file });
  const api = sb.global.Penta5AttackTxtConvert;
  if (!api || typeof api.convertThreeDingHistoryHitDelete !== "function") {
    throw new Error("转换库未导出回删接口");
  }
  if (typeof api.convertThreeDingGenerateOnly !== "function") {
    throw new Error("转换库未导出生成接口");
  }
  return api;
}

function httpJson(url, opts) {
  opts = opts || {};
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    const body = opts.body ? JSON.stringify(opts.body) : null;
    const req = http.request(
      {
        hostname: u.hostname,
        port: u.port || 80,
        path: u.pathname + u.search,
        method: opts.method || "GET",
        headers: Object.assign(
          { Accept: "application/json" },
          body
            ? { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(body) }
            : {},
          opts.headers || {}
        ),
        timeout: opts.timeout || 120000
      },
      (res) => {
        let buf = "";
        res.setEncoding("utf8");
        res.on("data", (c) => (buf += c));
        res.on("end", () => {
          let data = null;
          try {
            data = JSON.parse(buf);
          } catch (_e) {
            data = { raw: buf.slice(0, 300) };
          }
          if (res.statusCode && res.statusCode >= 400) {
            reject(
              new Error(
                "HTTP " +
                  res.statusCode +
                  " " +
                  ((data && (data.error || data.message)) || buf.slice(0, 120))
              )
            );
            return;
          }
          resolve({ headers: res.headers, data });
        });
      }
    );
    req.on("error", reject);
    req.on("timeout", () => {
      req.destroy();
      reject(new Error("timeout"));
    });
    if (body) req.write(body);
    req.end();
  });
}

function cookieFromSetCookie(setCookie) {
  if (!setCookie) return "";
  const arr = Array.isArray(setCookie) ? setCookie : [setCookie];
  return arr
    .map((s) => String(s).split(";")[0])
    .filter(Boolean)
    .join("; ");
}

async function syncAliyunToLocal() {
  const errors = [];
  for (const base of PANEL_BASES) {
    try {
      const root = base.replace(/\/$/, "");
      const login = await httpJson(root + "/login", {
        method: "POST",
        body: { password: PANEL_PASSWORD },
        timeout: 15000
      });
      const cookie = cookieFromSetCookie(login.headers && login.headers["set-cookie"]);
      const resp = await httpJson(root + "/converter-history?limit=" + HIST_LIMIT, {
        timeout: 120000,
        headers: cookie ? { Cookie: cookie } : {}
      });
      const data = resp.data || {};
      const history = Array.isArray(data.history) ? data.history : [];
      if (history.length < HIST_LIMIT) {
        throw new Error("历史不足 " + history.length);
      }
      const pack = {
        history: history.slice(0, HIST_LIMIT),
        source: root,
        sharedHistorySource: data.sharedHistorySource || "rds",
        sharedHistoryRdsLatestPeriod: data.sharedHistoryRdsLatestPeriod || "",
        syncedAt: data.sharedHistorySyncedAt || new Date().toISOString()
      };
      fs.writeFileSync(
        HIST_FILE,
        JSON.stringify(
          {
            updatedAt: pack.syncedAt,
            source: pack.source,
            sharedHistorySource: pack.sharedHistorySource,
            sharedHistoryRdsLatestPeriod: pack.sharedHistoryRdsLatestPeriod,
            limit: HIST_LIMIT,
            history: pack.history
          },
          null,
          2
        ),
        "utf8"
      );
      return pack;
    } catch (e) {
      errors.push(base + " → " + (e && e.message ? e.message : e));
    }
  }
  throw new Error(errors.join("\n"));
}

function loadLocalHistory() {
  if (!fs.existsSync(HIST_FILE)) throw new Error("无本地历史，请先同步");
  const raw = JSON.parse(fs.readFileSync(HIST_FILE, "utf8"));
  const history = Array.isArray(raw.history) ? raw.history : [];
  if (!history.length) throw new Error("本地历史为空");
  return {
    history: history.slice(0, HIST_LIMIT),
    source: raw.source || HIST_FILE,
    sharedHistorySource: raw.sharedHistorySource || "local",
    sharedHistoryRdsLatestPeriod: raw.sharedHistoryRdsLatestPeriod || "",
    updatedAt: raw.updatedAt || ""
  };
}

function resolveAttack(text) {
  const t = String(text || "").trim();
  if (t) return t;
  if (fs.existsSync(ATTACK_LINE)) {
    const line = fs.readFileSync(ATTACK_LINE, "utf8").trim();
    if (line) return line;
  }
  throw new Error("无攻击语：请粘贴，或先跑抓码生成 攻击语一行.txt");
}

function pickCodes(result) {
  if (!result) return [];
  if (Array.isArray(result.codes)) return result.codes;
  if (Array.isArray(result.tokens)) return result.tokens;
  if (result.multiCombo && Array.isArray(result.groups)) {
    return result.groups.reduce((a, g) => a.concat(g.codes || g.tokens || []), []);
  }
  return [];
}

function sendJson(res, code, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(code, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store"
  });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let buf = "";
    req.setEncoding("utf8");
    req.on("data", (c) => (buf += c));
    req.on("end", () => {
      if (!buf) return resolve({});
      try {
        resolve(JSON.parse(buf));
      } catch (e) {
        reject(new Error("JSON 无效"));
      }
    });
    req.on("error", reject);
  });
}

function openBrowser(url) {
  const plat = process.platform;
  try {
    if (plat === "win32") spawn("cmd", ["/c", "start", "", url], { detached: true, stdio: "ignore" });
    else if (plat === "darwin") spawn("open", [url], { detached: true, stdio: "ignore" });
    else spawn("xdg-open", [url], { detached: true, stdio: "ignore" });
  } catch (_e) {
    /* ignore */
  }
}

const api = loadApi();

const server = http.createServer(async (req, res) => {
  try {
    const u = new URL(req.url, "http://127.0.0.1");
    const p = u.pathname;

    if (req.method === "GET" && (p === "/" || p === "/index.html")) {
      res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
      res.end(fs.readFileSync(HTML_FILE));
      return;
    }
    if (req.method === "GET" && p === "/txt_attack_convert.js") {
      res.writeHead(200, { "Content-Type": "application/javascript; charset=utf-8" });
      res.end(fs.readFileSync(path.join(DIR, "txt_attack_convert.js")));
      return;
    }
    if (req.method === "GET" && p === "/api/meta") {
      sendJson(res, 200, {
        ok: true,
        dir: DIR,
        histExists: fs.existsSync(HIST_FILE),
        attackExists: fs.existsSync(ATTACK_LINE),
        floor: api.THREE_DING_HIT_DELETE_FLOOR || 498,
        port: PORT
      });
      return;
    }
    if (req.method === "POST" && p === "/api/sync") {
      const pack = await syncAliyunToLocal();
      const latest = pack.history[0] || {};
      sendJson(res, 200, {
        ok: true,
        historyCount: pack.history.length,
        source: pack.source,
        sharedHistorySource: pack.sharedHistorySource,
        latestPeriod: latest.period || "",
        latestNumbers: latest.numbers || [],
        syncedAt: pack.syncedAt
      });
      return;
    }
    if (req.method === "POST" && p === "/api/generate") {
      const body = await readBody(req);
      const attack = resolveAttack(body.text);
      if (body.sync !== false) await syncAliyunToLocal();
      const result = api.convertThreeDingGenerateOnly(attack, {});
      if (!result || result.ok === false) {
        sendJson(res, 400, { ok: false, message: (result && result.message) || "生成失败" });
        return;
      }
      const codes = pickCodes(result);
      const payload = {
        ok: true,
        stage: "generated",
        attack,
        afterFilter: result.afterFilter != null ? result.afterFilter : codes.length,
        count: codes.length,
        label: result.label,
        note: result.note,
        codes,
        text: codes.join(" ")
      };
      fs.writeFileSync(CAND_JSON, JSON.stringify(payload, null, 2), "utf8");
      if (body.text && String(body.text).trim()) {
        fs.writeFileSync(ATTACK_LINE, String(body.text).trim() + "\n", "utf8");
      }
      sendJson(res, 200, payload);
      return;
    }
    if (req.method === "POST" && p === "/api/backdelete") {
      const body = await readBody(req);
      const attack = resolveAttack(body.text);
      if (body.sync !== false) await syncAliyunToLocal();
      const pack = loadLocalHistory();
      const result = api.convertThreeDingHistoryHitDelete(attack, pack.history, {});
      if (!result || result.ok === false) {
        sendJson(res, 400, { ok: false, message: (result && result.message) || "回删失败" });
        return;
      }
      const codes = pickCodes(result);
      const latest = pack.history[0] || {};
      const payload = {
        ok: true,
        stage: "backdeleted",
        attack,
        historySource: pack.source,
        historyCount: pack.history.length,
        latestPeriod: latest.period || "",
        afterFilter: result.afterFilter,
        deletedUnique: result.deletedUnique,
        scanned: result.scanned,
        stoppedAtFloor: !!result.stoppedAtFloor,
        remainFloor: result.remainFloor != null ? result.remainFloor : 498,
        scanFromPeriod: result.scanFromPeriod || "",
        scanToPeriod: result.scanToPeriod || "",
        count: codes.length,
        label: result.label,
        note: result.note,
        hitSamples: result.hitSamples || [],
        codes,
        text: codes.join(" ")
      };
      const summary = [
        "【桌面版回删 · 与锁定包同一口径】",
        "攻击语: " + attack,
        "历史: " + pack.source + " / " + pack.history.length + " 期（本期 " + (latest.period || "") + "）",
        "排除后: " + payload.afterFilter,
        "已删: " + payload.deletedUnique + " 扫期: " + payload.scanned,
        "现剩: " + payload.count + (payload.stoppedAtFloor ? "（触底线498）" : ""),
        "说明: " + (payload.note || ""),
        "",
        payload.text,
        ""
      ].join("\n");
      fs.writeFileSync(OUT_TXT, summary, "utf8");
      fs.writeFileSync(OUT_JSON, JSON.stringify(payload, null, 2), "utf8");
      sendJson(res, 200, payload);
      return;
    }
    if (req.method === "POST" && p === "/api/open-dir") {
      const plat = process.platform;
      if (plat === "win32") spawn("explorer", [DIR], { detached: true, stdio: "ignore" });
      else if (plat === "darwin") spawn("open", [DIR], { detached: true, stdio: "ignore" });
      else spawn("xdg-open", [DIR], { detached: true, stdio: "ignore" });
      sendJson(res, 200, { ok: true, dir: DIR });
      return;
    }
    sendJson(res, 404, { ok: false, error: "Not Found" });
  } catch (e) {
    sendJson(res, 500, { ok: false, message: String(e && e.message ? e.message : e) });
  }
});

server.listen(PORT, "127.0.0.1", () => {
  const url = "http://127.0.0.1:" + PORT + "/";
  console.log("桌面版已启动: " + url);
  console.log("目录: " + DIR);
  console.log("口径: 今日命中删 · 不少于498");
  console.log("保持此黑窗开着，不要关。关掉就打不开网页。");
  openBrowser(url);
});
server.on("error", (err) => {
  if (err && err.code === "EADDRINUSE") {
    console.error("端口 " + PORT + " 已被占用。正在打开已有页面…");
    openBrowser("http://127.0.0.1:" + PORT + "/");
    console.log("若网页仍打不开，请先关掉旧的 node 黑窗再重开 START.bat");
    setInterval(() => {}, 1 << 30);
    return;
  }
  console.error(err && err.stack ? err.stack : err);
  process.exit(1);
});
