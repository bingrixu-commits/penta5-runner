#!/usr/bin/env node
/**
 * 本机回删工具（对齐面板高命中口径）
 *
 * 口径：纯旧码回删、不加排除码
 *   完整 1000 组 → 扫阿里云近 200 期唯一旧码 → 回删 200 → 剩 800
 *
 * 攻击语只用来识别「千百十 / 百十个 / …」哪一种三位组合；
 * 定位/对数/合尾/二数合排除一律不参与回删（与面板「三定回删命中率」一致）。
 *
 *   node 本机回删.js --out
 *   node 本机回删.js --offline --out
 */
"use strict";

const fs = require("fs");
const path = require("path");
const http = require("http");
const vm = require("vm");

const DIR = __dirname;
const HIST_FILE = path.join(DIR, "开奖历史.json");
const ATTACK_LINE = path.join(DIR, "攻击语一行.txt");
const OUT_TXT = path.join(DIR, "回删结果.txt");
const OUT_TXT_1 = path.join(DIR, "回删结果-第1批.txt");
const OUT_TXT_2 = path.join(DIR, "回删结果-第2批.txt");
const OUT_JSON = path.join(DIR, "回删结果.json");
const HIST_LIMIT = 200;
const BATCH1_SIZE = 300;
const FULL_POOL = "0123456789";
const PANEL_PASSWORD = process.env.PANEL_PASSWORD || "147258";
const PANEL_BASES = (
  process.env.PANEL_BASES ||
  "http://8.210.5.221:3001,http://127.0.0.1:3001"
)
  .split(",")
  .map((s) => s.trim())
  .filter(Boolean);

function findConvertJs() {
  const cands = [
    path.join(DIR, "txt_attack_convert.js"),
    path.resolve(DIR, "../../penta5-runner/txt_attack_convert.js"),
    path.resolve(DIR, "../penta5-runner/txt_attack_convert.js"),
    "/root/penta5-runner/txt_attack_convert.js",
    path.resolve(process.cwd(), "penta5-runner/txt_attack_convert.js")
  ];
  for (const p of cands) if (fs.existsSync(p)) return p;
  return null;
}

function loadApi() {
  const file = findConvertJs();
  if (!file) throw new Error("未找到 txt_attack_convert.js");
  const code = fs.readFileSync(file, "utf8");
  const sb = { console, module: { exports: {} }, exports: {}, require };
  sb.global = sb;
  vm.runInNewContext(code, sb, { filename: file });
  const api = sb.global.Penta5AttackTxtConvert;
  if (!api || typeof api.convertThreeDingBackDelete !== "function") {
    throw new Error("转换库未导出 convertThreeDingBackDelete");
  }
  return { api, file };
}

function httpJson(url, opts) {
  opts = opts || {};
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    const body = opts.body ? JSON.stringify(opts.body) : null;
    const req = http.request(
      {
        hostname: u.hostname,
        port: u.port || (u.protocol === "https:" ? 443 : 80),
        path: u.pathname + u.search,
        method: opts.method || "GET",
        headers: Object.assign(
          { Accept: "application/json" },
          body
            ? { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(body) }
            : {},
          opts.headers || {}
        ),
        timeout: opts.timeout || 120000
      },
      (res) => {
        let buf = "";
        res.setEncoding("utf8");
        res.on("data", (c) => (buf += c));
        res.on("end", () => {
          let data = null;
          try {
            data = JSON.parse(buf);
          } catch (_e) {
            data = { raw: buf.slice(0, 300) };
          }
          if (res.statusCode && res.statusCode >= 400) {
            const msg =
              (data && (data.error || data.message || data.reason)) || buf.slice(0, 160);
            reject(new Error("HTTP " + res.statusCode + " " + url + " :: " + msg));
            return;
          }
          resolve({ status: res.statusCode || 0, headers: res.headers, data });
        });
      }
    );
    req.on("error", reject);
    req.on("timeout", () => {
      req.destroy();
      reject(new Error("timeout " + url));
    });
    if (body) req.write(body);
    req.end();
  });
}

function cookieFromSetCookie(setCookie) {
  const arr = Array.isArray(setCookie) ? setCookie : setCookie ? [setCookie] : [];
  return arr
    .map((s) => String(s).split(";")[0])
    .filter(Boolean)
    .join("; ");
}

async function fetchAliyunHistory200(base) {
  const root = String(base || "").replace(/\/$/, "");
  const login = await httpJson(root + "/login", {
    method: "POST",
    body: { password: PANEL_PASSWORD },
    timeout: 15000
  });
  const cookie = cookieFromSetCookie(login.headers && login.headers["set-cookie"]);
  const hist = await httpJson(root + "/converter-history?limit=" + HIST_LIMIT, {
    headers: cookie ? { Cookie: cookie } : {},
    timeout: 120000
  });
  const data = hist.data || {};
  const rows = Array.isArray(data.history) ? data.history : [];
  if (rows.length < HIST_LIMIT) {
    throw new Error(
      "历史不足 " + HIST_LIMIT + " 期（实得 " + rows.length + "）@" + root
    );
  }
  return {
    source: root,
    sharedHistorySource: data.source || data.sharedHistorySource || "rds",
    sharedHistoryRdsLatestPeriod:
      data.rdsPeriod || data.sharedHistoryRdsLatestPeriod || "",
    history: rows.slice(0, HIST_LIMIT),
    updatedAt: new Date().toISOString()
  };
}

async function syncAliyunToLocal() {
  let lastErr = null;
  for (const base of PANEL_BASES) {
    try {
      const pack = await fetchAliyunHistory200(base);
      fs.writeFileSync(
        HIST_FILE,
        JSON.stringify(
          {
            updatedAt: pack.updatedAt,
            source: pack.source,
            sharedHistorySource: pack.sharedHistorySource,
            sharedHistoryRdsLatestPeriod: pack.sharedHistoryRdsLatestPeriod,
            refreshedFromRds: true,
            limit: HIST_LIMIT,
            history: pack.history
          },
          null,
          2
        ),
        "utf8"
      );
      return pack;
    } catch (e) {
      lastErr = e;
    }
  }
  throw lastErr || new Error("阿里云历史拉取失败");
}

function loadLocalHistory() {
  if (!fs.existsSync(HIST_FILE)) {
    throw new Error("本地无历史文件: " + HIST_FILE);
  }
  const j = JSON.parse(fs.readFileSync(HIST_FILE, "utf8"));
  const history = Array.isArray(j.history) ? j.history : [];
  if (!history.length) throw new Error("本地历史为空");
  return {
    source: j.source || "local",
    sharedHistorySource: j.sharedHistorySource || "local",
    sharedHistoryRdsLatestPeriod: j.sharedHistoryRdsLatestPeriod || "",
    history: history.slice(0, HIST_LIMIT),
    updatedAt: j.updatedAt || ""
  };
}

function parseArgs(argv) {
  const out = { text: "", out: false, offline: false, help: false };
  for (let i = 2; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--text") out.text = String(argv[++i] || "");
    else if (a === "--out") out.out = true;
    else if (a === "--offline") out.offline = true;
    else if (a === "--help" || a === "-h") out.help = true;
    else if (!a.startsWith("-") && !out.text) out.text = a;
  }
  return out;
}

function loadAttackText(forced) {
  if (forced && String(forced).trim()) return String(forced).trim();
  if (fs.existsSync(ATTACK_LINE)) {
    const line = fs
      .readFileSync(ATTACK_LINE, "utf8")
      .split(/\r?\n/)
      .map((s) => s.trim())
      .filter(Boolean)
      .pop();
    if (line) return line;
  }
  throw new Error("无攻击语：请先跑抓码，或 --text 传入（仅用于识别三位组合）");
}

/** 从攻击语识别三位组合名；排除条件一律忽略 */
function detectComboName(raw) {
  const s = String(raw || "");
  if (/千百十个/.test(s)) return "百十个";
  if (/百十个/.test(s)) return "百十个";
  if (/千百个/.test(s)) return "千百个";
  if (/千十个|万十个/.test(s)) return "千十个";
  if (/千百十/.test(s)) return "千百十";
  // 看池子标签
  const hasQ = /千\d{5,}/.test(s);
  const hasB = /百\d{5,}/.test(s);
  const hasS = /十\d{5,}/.test(s);
  const hasG = /个\d{5,}/.test(s);
  if (hasQ && hasB && hasS && !hasG) return "千百十";
  if (!hasQ && hasB && hasS && hasG) return "百十个";
  if (hasQ && hasB && !hasS && hasG) return "千百个";
  if (hasQ && !hasB && hasS && hasG) return "千十个";
  return "千百十";
}

/** 纯旧码攻击语：满池 1000，不加任何排除 */
function buildPureOldCodeAttack(comboName) {
  const name = String(comboName || "千百十");
  if (name === "百十个") return "百" + FULL_POOL + "十" + FULL_POOL + "个" + FULL_POOL + "三定各";
  if (name === "千百个") return "千" + FULL_POOL + "百" + FULL_POOL + "个" + FULL_POOL + "三定各";
  if (name === "千十个") return "千" + FULL_POOL + "十" + FULL_POOL + "个" + FULL_POOL + "三定各";
  return "千" + FULL_POOL + "百" + FULL_POOL + "十" + FULL_POOL + "三定各";
}

async function main() {
  const args = parseArgs(process.argv);
  if (args.help) {
    console.log(`本机回删（纯旧码回删200剩800）

  node 本机回删.js --out
  node 本机回删.js --offline --out

对齐面板：不加排除码；完整1000→回删200→剩800。
攻击语只用来认组合（千百十/百十个…）。`);
    return;
  }

  const attackRaw = loadAttackText(args.text);
  const comboName = detectComboName(attackRaw);
  const pureAttack = buildPureOldCodeAttack(comboName);
  console.log("【本机回删】纯旧码 · 回删200剩800 · 不加排除");
  console.log("原攻击语(仅认组合): " + attackRaw);
  console.log("组合: " + comboName);
  console.log("回删用纯旧码串: " + pureAttack);

  let pack;
  if (args.offline) {
    pack = loadLocalHistory();
    console.log(
      "⚠ --offline 未刷新: " + HIST_FILE + (pack.updatedAt ? " @ " + pack.updatedAt : "")
    );
  } else {
    console.log("从阿里云拉 " + HIST_LIMIT + " 期到本机…");
    pack = await syncAliyunToLocal();
    console.log(
      "已写入: " +
        HIST_FILE +
        " ← " +
        pack.source +
        " (" +
        (pack.sharedHistorySource || "rds") +
        ")" +
        (pack.sharedHistoryRdsLatestPeriod
          ? " rdsLatest=" + pack.sharedHistoryRdsLatestPeriod
          : "")
    );
  }

  const { api, file } = loadApi();
  console.log("转换库: " + file);
  const latest = pack.history[0] || {};
  console.log(
    "回删用本地历史: " +
      pack.history.length +
      " 期，本期起 " +
      (latest.period || "?") +
      " " +
      JSON.stringify(latest.numbers || [])
  );

  const result = api.convertThreeDingBackDelete(pureAttack, pack.history, {});
  if (!result || result.ok === false) {
    console.error("回删失败: " + ((result && result.message) || "unknown"));
    process.exit(2);
  }

  const codes = result.codes || result.tokens || [];
  const list = Array.isArray(codes) ? codes.map(String) : [];
  const usedCombo = result.comboName || result.combo || comboName;
  let copyParts = result.copyParts;
  if (
    (!copyParts || !copyParts.part1Text) &&
    typeof api.threeDingCopyParts === "function"
  ) {
    copyParts = api.threeDingCopyParts(list, BATCH1_SIZE, usedCombo);
  }
  const batch1 = (copyParts && copyParts.part1Tokens) || list.slice(0, BATCH1_SIZE);
  const batch2 = (copyParts && copyParts.part2Tokens) || list.slice(BATCH1_SIZE);
  const text1 =
    (copyParts && copyParts.part1Text) ||
    (typeof api.formatThreeDingGeList === "function"
      ? api.formatThreeDingGeList(batch1, null, usedCombo)
      : batch1.join(","));
  const text2 =
    (copyParts && copyParts.part2Text) ||
    (batch2.length
      ? typeof api.formatThreeDingGeList === "function"
        ? api.formatThreeDingGeList(batch2, null, usedCombo)
        : batch2.join(",")
      : "");
  const textOut =
    result.text ||
    result.attackText ||
    (typeof api.formatThreeDingGeList === "function"
      ? api.formatThreeDingGeList(list, null, usedCombo)
      : list.join(","));

  const summary = [
    "【本机回删结果 · 纯旧码回删200剩800 · 不加排除】",
    "原攻击语(仅认组合): " + attackRaw,
    "组合: " + usedCombo,
    "纯旧码串: " + pureAttack,
    "历史文件: " + HIST_FILE,
    "拉取来源: " + pack.source + " / " + (pack.sharedHistorySource || "rds"),
    "历史期数: " + pack.history.length + "（本期 " + (latest.period || "?") + "）",
    "排除后/宇宙: " + (result.afterFilter != null ? result.afterFilter : "--"),
    "已删唯一旧码: " + (result.deletedUnique != null ? result.deletedUnique : "--"),
    "扫期: " + (result.scanned != null ? result.scanned : "--"),
    "现剩: " + (result.count != null ? result.count : list.length) + "（目标800）",
    "格式: 空位x + 逗号隔开 + 各收尾；分批 第1批 " +
      batch1.length +
      " → 回删结果-第1批.txt；第2批 " +
      batch2.length +
      " → 回删结果-第2批.txt",
    "说明: " + (result.note || result.label || ""),
    "",
    "—— 第1批（先复制这批）——",
    text1,
    "",
    "—— 第2批（第一批打完再复制）——",
    text2 || "（无，全部已在第1批）",
    "",
    "—— 全部 ——",
    textOut,
    ""
  ]
    .filter((line, i, arr) => line !== "" || (i > 0 && arr[i - 1] !== ""))
    .join("\n");

  console.log(summary);

  if (args.out) {
    fs.writeFileSync(OUT_TXT, summary, "utf8");
    fs.writeFileSync(OUT_TXT_1, text1 + (text1 ? "\n" : ""), "utf8");
    fs.writeFileSync(OUT_TXT_2, text2 + (text2 ? "\n" : ""), "utf8");
    fs.writeFileSync(
      OUT_JSON,
      JSON.stringify(
        {
          ok: true,
          mode: "pure-old-code-backdelete-200-800",
          attackRaw,
          pureAttack,
          historyCount: pack.history.length,
          historyFile: HIST_FILE,
          historySource: pack.source,
          latestPeriod: latest.period || "",
          comboName: usedCombo,
          batch1Size: BATCH1_SIZE,
          batch1Text: text1,
          batch2Text: text2,
          allText: textOut,
          batch1: batch1,
          batch2: batch2,
          result: {
            label: result.label,
            note: result.note,
            afterFilter: result.afterFilter,
            deletedUnique: result.deletedUnique,
            scanned: result.scanned,
            targetRemain: result.targetRemain != null ? result.targetRemain : 800,
            count: result.count != null ? result.count : list.length
          },
          codes: list
        },
        null,
        2
      ),
      "utf8"
    );
    console.log("已写入: " + OUT_TXT);
    console.log("已写入: " + OUT_TXT_1 + "（" + batch1.length + " 个）");
    console.log("已写入: " + OUT_TXT_2 + "（" + batch2.length + " 个）");
    console.log("已写入: " + OUT_JSON);
  }
}

main().catch((e) => {
  console.error("[ERROR]", e && e.message ? e.message : e);
  process.exit(1);
});
