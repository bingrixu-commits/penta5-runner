@echo off
chcp 65001 >nul
cd /d "%~dp0"
title huishan-200-800
echo 一键回删：纯旧码回删200剩800（不加排除）
echo.
where node >nul 2>nul
if errorlevel 1 (
  echo [ERROR] 未找到 node
  pause
  exit /b 1
)
node "%~dp0本机回删.js" --out
if errorlevel 1 (
  echo [ERROR] 回删失败
  pause
  exit /b 1
)
echo.
if exist "%~dp0回删结果-第1批.txt" (
  type "%~dp0回删结果-第1批.txt" | clip
  echo 第1批已复制到剪贴板
  echo 第2批文件: 回删结果-第2批.txt
)
echo.
pause
